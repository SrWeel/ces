create definer = root@localhost view efacsistema_producto_vista as
select `cesdb_aroriginal`.`efacsistema_producto`.`prod_id`                      AS `prod_id`,
       `cesdb_aroriginal`.`efacsistema_producto`.`emp_id`                       AS `emp_id`,
       `cesdb_aroriginal`.`efacsistema_producto`.`catgp_id`                     AS `catgp_id`,
       `cesdb_aroriginal`.`efacfactura_categproducto`.`catgp_nombre`            AS `catgp_nombre`,
       `cesdb_aroriginal`.`efacsistema_producto`.`tipp_id`                      AS `tipp_id`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_codigo`                  AS `prod_codigo`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_nombre`                  AS `prod_nombre`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_precio`                  AS `prod_precio`,
       `cesdb_aroriginal`.`efacsistema_producto`.`impu_codigo`                  AS `impu_codigo`,
       `cesdb_aroriginal`.`efacsistema_producto`.`tari_codigo`                  AS `tari_codigo`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_fecharegistro`           AS `prod_fecharegistro`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_activo`                  AS `prod_activo`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_nivel`                   AS `prod_nivel`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_nombredespliegue`        AS `prod_nombredespliegue`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_codigotarifario`         AS `prod_codigotarifario`,
       `cesdb_aroriginal`.`efacsistema_producto`.`prod_preciotarifarionacional` AS `prod_preciotarifarionacional`
from (`cesdb_aroriginal`.`efacsistema_producto` join `cesdb_aroriginal`.`efacfactura_categproducto`
      on (`cesdb_aroriginal`.`efacsistema_producto`.`catgp_id` =
          `cesdb_aroriginal`.`efacfactura_categproducto`.`catgp_id`));

