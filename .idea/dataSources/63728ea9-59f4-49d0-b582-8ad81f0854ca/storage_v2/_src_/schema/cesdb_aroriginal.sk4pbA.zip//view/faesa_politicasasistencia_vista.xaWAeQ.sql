create definer = root@localhost view faesa_politicasasistencia_vista as
select `cesdb_aroriginal`.`faesa_politicasasistencia`.`polasis_id`           AS `polasis_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                  AS `centro_nombre`,
       `cesdb_aroriginal`.`faesa_politicasasistencia`.`emp_id`               AS `emp_id`,
       `cesdb_aroriginal`.`faesa_politicasasistencia`.`polasis_horaentradam` AS `polasis_horaentradam`,
       `cesdb_aroriginal`.`faesa_politicasasistencia`.`polasis_horasalidam`  AS `polasis_horasalidam`,
       `cesdb_aroriginal`.`faesa_politicasasistencia`.`polasis_horaentradat` AS `polasis_horaentradat`,
       `cesdb_aroriginal`.`faesa_politicasasistencia`.`polasis_horasalidat`  AS `polasis_horasalidat`
from (`cesdb_aroriginal`.`faesa_politicasasistencia` join `cesdb_aroriginal`.`dns_centrosalud`
      on (`cesdb_aroriginal`.`faesa_politicasasistencia`.`centro_id` =
          `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`));

