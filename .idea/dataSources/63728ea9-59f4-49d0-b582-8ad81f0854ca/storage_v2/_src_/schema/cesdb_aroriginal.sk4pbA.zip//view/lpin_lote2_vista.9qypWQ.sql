create definer = root@localhost view lpin_lote2_vista as
select `cesdb_aroriginal`.`lpin_lote`.`lottar_id`                                                                   AS `lottar_id`,
       `cesdb_aroriginal`.`lpin_lote`.`lottar_recap`                                                                AS `lottar_recap`,
       `cesdb_aroriginal`.`lpin_redcobro`.`redc_nombre`                                                             AS `redc_nombre`,
       `cesdb_aroriginal`.`lpin_lote`.`lottar_fechai`                                                               AS `lottar_fechai`,
       `cesdb_aroriginal`.`lpin_lote`.`lottar_fechaf`                                                               AS `lottar_fechaf`,
       round((select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `saldo`
              from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                    on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                        `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
              where `cesdb_aroriginal`.`lpin_cobropago`.`lote_id` = `cesdb_aroriginal`.`lpin_lote`.`lottar_id`),
             2)                                                                                                     AS `total`,
       round((select sum(`cesdb_aroriginal`.`lpin_lqtransacciones`.`lqtran_deposito`) AS `pagado`
              from (`cesdb_aroriginal`.`lpin_lqtarjetacredito` join `cesdb_aroriginal`.`lpin_lqtransacciones`
                    on (`cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_enlace` =
                        `cesdb_aroriginal`.`lpin_lqtransacciones`.`tpliq_enlace`))
              where `cesdb_aroriginal`.`lpin_lqtransacciones`.`lqtran_recap` =
                    `cesdb_aroriginal`.`lpin_lote`.`lottar_id`),
             2)                                                                                                     AS `pagado`,
       round(ifnull((select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `saldo`
                     from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                           on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                               `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                     where `cesdb_aroriginal`.`lpin_cobropago`.`lote_id` = `cesdb_aroriginal`.`lpin_lote`.`lottar_id`),
                    0) - ifnull((select sum(`cesdb_aroriginal`.`lpin_lqtransacciones`.`lqtran_deposito`) AS `pagado`
                                 from (`cesdb_aroriginal`.`lpin_lqtarjetacredito` join `cesdb_aroriginal`.`lpin_lqtransacciones`
                                       on (`cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_enlace` =
                                           `cesdb_aroriginal`.`lpin_lqtransacciones`.`tpliq_enlace`))
                                 where `cesdb_aroriginal`.`lpin_lqtransacciones`.`lqtran_recap` =
                                       `cesdb_aroriginal`.`lpin_lote`.`lottar_id`), 0),
             2)                                                                                                     AS `saldo`
from (`cesdb_aroriginal`.`lpin_lote` left join `cesdb_aroriginal`.`lpin_redcobro`
      on (`cesdb_aroriginal`.`lpin_lote`.`redc_id` = `cesdb_aroriginal`.`lpin_redcobro`.`redc_id`));

