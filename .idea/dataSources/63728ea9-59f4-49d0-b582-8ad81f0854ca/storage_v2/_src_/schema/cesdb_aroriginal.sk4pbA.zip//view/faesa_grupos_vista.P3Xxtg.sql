create definer = root@localhost view faesa_grupos_vista as
select `cesdb_aroriginal`.`faesa_grupos`.`grup_id`          AS `grup_id`,
       `cesdb_aroriginal`.`faesa_grupos`.`emp_id`           AS `emp_id`,
       `cesdb_aroriginal`.`faesa_grupos`.`grup_nombre`      AS `grup_nombre`,
       `cesdb_aroriginal`.`faesa_grupos`.`grup_ri`          AS `grup_ri`,
       `cesdb_aroriginal`.`faesa_grupos`.`grup_rf`          AS `grup_rf`,
       `cesdb_aroriginal`.`faesa_grupos`.`centro_id`        AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre` AS `centro_nombre`
from (`cesdb_aroriginal`.`faesa_grupos` join `cesdb_aroriginal`.`dns_centrosalud`
      on (`cesdb_aroriginal`.`faesa_grupos`.`centro_id` = `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`));

