create definer = root@localhost view dns_inventariopr_vista as
select `cesdb_aroriginal`.`dns_inventariopr`.`inven_id`               AS `inven_id`,
       `cesdb_aroriginal`.`dns_categoriapr`.`categ_nombre`            AS `categ_nombre`,
       `cesdb_aroriginal`.`dns_inventariopr`.`inven_codigo`           AS `inven_codigo`,
       `cesdb_aroriginal`.`dns_inventariopr`.`inven_descripcion`      AS `inven_descripcion`,
       `cesdb_aroriginal`.`dns_inventariopr`.`inven_cantidadalafecha` AS `inven_cantidadalafecha`,
       `cesdb_aroriginal`.`faesa_estadoinv`.`estinv_nombre`           AS `estinv_nombre`,
       `cesdb_aroriginal`.`dns_inventariopr`.`centro_id`              AS `centro_id`,
       `cesdb_aroriginal`.`app_usuario`.`usua_nombre`                 AS `usua_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_apellido`               AS `usua_apellido`,
       `cesdb_aroriginal`.`dns_inventariopr`.`inven_activo`           AS `inven_activo`,
       `cesdb_aroriginal`.`dns_inventariopr`.`estinv_id`              AS `estinv_id`,
       `cesdb_aroriginal`.`dns_inventariopr`.`emp_id`                 AS `emp_id`
from (((`cesdb_aroriginal`.`dns_inventariopr` left join `cesdb_aroriginal`.`dns_categoriapr`
        on (`cesdb_aroriginal`.`dns_inventariopr`.`categ_id` =
            `cesdb_aroriginal`.`dns_categoriapr`.`categ_id`)) left join `cesdb_aroriginal`.`faesa_estadoinv`
       on (`cesdb_aroriginal`.`dns_inventariopr`.`estinv_id` =
           `cesdb_aroriginal`.`faesa_estadoinv`.`estinv_id`)) join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`dns_inventariopr`.`usua_id` = `cesdb_aroriginal`.`app_usuario`.`usua_id`));

