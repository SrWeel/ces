create definer = root@localhost view dns_centrosalud_origen as
select if(`cesdb_aroriginal`.`dns_centrosalud`.`centro_id` = 1, 55,
          `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`) AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre` AS `centro_nombre`
from `cesdb_aroriginal`.`dns_centrosalud`;

