create definer = root@localhost view dns_newhospitalizacionconsultaexterna_vista as
select `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`conext_id`                                        AS `conext_id`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `npaciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `atenc_hc`,
       `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`conext_fechar`                                    AS `conext_fechar`,
       `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`conext_horar`                                     AS `conext_horar`,
       concat(substr(`cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`conext_notasdeevolucion`, 1, 200),
              '...')                                                                                                 AS `conext_notasdeevolucion`,
       concat(substr(`cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`conext_prescripciones`, 1, 200),
              '...')                                                                                                 AS `conext_prescripciones`,
       `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`conext_fecharegistro`                             AS `conext_fecharegistro`,
       `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`atenc_id`                                         AS `atenc_id`,
       `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`clie_id`                                          AS `clie_id`,
       `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`anam_id`                                          AS `anam_id`
from ((`cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna` join `cesdb_aroriginal`.`dns_atencion`
       on (`cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`atenc_id` =
           `cesdb_aroriginal`.`dns_atencion`.`atenc_id`)) join `cesdb_aroriginal`.`app_cliente`
      on (`cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`clie_id` =
          `cesdb_aroriginal`.`app_cliente`.`clie_id`));

