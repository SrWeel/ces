create definer = root@localhost view dns_imagenologia_vista as
select `cesdb_aroriginal`.`dns_imagenologia`.`imgag_id`                                                              AS `imgag_id`,
       `cesdb_aroriginal`.`dns_imagenologia`.`centro_id`                                                             AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_imagenologia`.`clie_id`                                                               AS `clie_id`,
       (select `cesdb_aroriginal`.`dns_diagnosticoimagensolicitud`.`diagn_descripcion`
        from `cesdb_aroriginal`.`dns_diagnosticoimagensolicitud`
        where `cesdb_aroriginal`.`dns_diagnosticoimagensolicitud`.`imgag_enlace` =
              `cesdb_aroriginal`.`dns_imagenologia`.`imgag_enlace`
        order by `cesdb_aroriginal`.`dns_diagnosticoimagensolicitud`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `imgag_hc`,
       `cesdb_aroriginal`.`dns_imagenologia`.`imgag_fecharegistro`                                                   AS `imgag_fecharegistro`,
       `cesdb_aroriginal`.`dns_imagenologia`.`usua_id`                                                               AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_imagenologia`.`atenc_id`                                                              AS `atenc_id`,
       `cesdb_aroriginal`.`dns_imagenologia`.`imgag_idexterno`                                                       AS `imgag_idexterno`,
       `cesdb_aroriginal`.`dns_imagenologia`.`imgag_tablaexterno`                                                    AS `imgag_tablaexterno`
from ((((`cesdb_aroriginal`.`dns_imagenologia` join `cesdb_aroriginal`.`app_cliente`
         on (`cesdb_aroriginal`.`dns_imagenologia`.`clie_id` =
             `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
        on (`cesdb_aroriginal`.`dns_imagenologia`.`centro_id` =
            `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_imagenologia`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_imagenologia`.`atenc_id` = `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

