create definer = `remote-user`@`192.168.100.10` view app_usuario_vistacmb as
select `cesdb_aroriginal`.`app_usuario`.`usua_id`                AS `usua_id`,
       `cesdb_aroriginal`.`app_usuario`.`usua_nombre`            AS `usua_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_apellido`          AS `usua_apellido`,
       `cesdb_aroriginal`.`dns_gridfuncionprofesional`.`prof_id` AS `prof_id`
from ((`cesdb_aroriginal`.`app_usuario` join `cesdb_aroriginal`.`dns_gridfuncionprofesional`
       on (`cesdb_aroriginal`.`app_usuario`.`usua_enlace` =
           `cesdb_aroriginal`.`dns_gridfuncionprofesional`.`usua_enlace`)) join `cesdb_arextension`.`dns_profesion`
      on (`cesdb_aroriginal`.`dns_gridfuncionprofesional`.`prof_id` = `cesdb_arextension`.`dns_profesion`.`prof_id`));

