create definer = root@localhost view lpin_masivocobropago_vista as
select `cesdb_aroriginal`.`lpin_masivocobropago`.`crb_id`             AS `crb_id`,
       `cesdb_aroriginal`.`lpin_masivocobropago`.`crb_fecha`          AS `crb_fecha`,
       `cesdb_aroriginal`.`lpin_ttransac`.`ttra_nombre`               AS `ttra_nombre`,
       `cesdb_aroriginal`.`lpin_masivocobropago`.`crb_cuenta`         AS `crb_cuenta`,
       `cesdb_aroriginal`.`lpin_masivocobropago`.`crb_ncomprobante`   AS `crb_ncomprobante`,
       `lpin_cuentasbancarias_vista`.`entif_nombre`                   AS `entif_nombre`,
       `cesdb_aroriginal`.`lpin_masivocobropago`.`crb_procesado`      AS `crb_procesado`,
       `cesdb_aroriginal`.`lpin_masivocobropago`.`crb_fechaprocesado` AS `crb_fechaprocesado`,
       `cesdb_aroriginal`.`lpin_masivocobropago`.`crb_fecharegistro`  AS `crb_fecharegistro`
from ((`cesdb_aroriginal`.`lpin_masivocobropago` join `cesdb_aroriginal`.`lpin_ttransac`
       on (`cesdb_aroriginal`.`lpin_masivocobropago`.`ttra_id` =
           `cesdb_aroriginal`.`lpin_ttransac`.`ttra_id`)) left join `cesdb_aroriginal`.`lpin_cuentasbancarias_vista`
      on (`cesdb_aroriginal`.`lpin_masivocobropago`.`cuentb_id` = `lpin_cuentasbancarias_vista`.`cuentb_id`));

