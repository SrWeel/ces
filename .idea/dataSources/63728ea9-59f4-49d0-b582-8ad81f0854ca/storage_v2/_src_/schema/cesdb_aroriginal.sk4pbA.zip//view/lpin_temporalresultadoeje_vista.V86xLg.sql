create definer = root@localhost view lpin_temporalresultadoeje_vista as
select 1                                                                                           AS `detcc_id`,
       ''                                                                                          AS `comcont_enlace`,
       `cesdb_aroriginal`.`lpin_temporalresultadoeje`.`detcc_cuentacontable`                       AS `detcc_cuentacontable`,
       'Resultado del Ejercicio'                                                                   AS `detcc_descricpion`,
       ''                                                                                          AS `detcc_referencia`,
       ''                                                                                          AS `detcc_entidad`,
       `cesdb_aroriginal`.`lpin_temporalresultadoeje`.`detcc_debe`                                 AS `detcc_debe`,
       `cesdb_aroriginal`.`lpin_temporalresultadoeje`.`detcc_haber`                                AS `detcc_haber`,
       0                                                                                           AS `centcost_id`,
       0                                                                                           AS `usua_id`,
       current_timestamp()                                                                         AS `detcc_fecharegistro`,
       `cesdb_aroriginal`.`lpin_temporalresultadoeje`.`detcc_cuentacontablep`                      AS `detcc_cuentacontablep`,
       `cesdb_aroriginal`.`lpin_temporalresultadoeje`.`comcont_fecha`                              AS `comcont_fecha`,
       0                                                                                           AS `comcont_anulado`,
       6                                                                                           AS `tipoa_id`,
       0                                                                                           AS `comcont_id`,
       ''                                                                                          AS `comcont_numeroc`,
       'Resultado del Ejercicio'                                                                   AS `comcont_concepto`,
       0                                                                                           AS `comcont_inicial`,
       `SPLIT_STR`(`cesdb_aroriginal`.`lpin_temporalresultadoeje`.`detcc_cuentacontablep`, '.', 1) AS `codcuenta`
from `cesdb_aroriginal`.`lpin_temporalresultadoeje`;

