create definer = root@localhost view lista_pacientes as
select `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`
union
select `cesdb_aroriginal`.`dns_newhospitalizacionanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newhospitalizacionanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newhospitalizacionanamesis`
union
select `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newemergenciaanamesis`
union
select `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`
union
select `cesdb_aroriginal`.`dns_atencion`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_atencion`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_atencion`
union
select `cesdb_aroriginal`.`dns_newreferencia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newreferencia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newreferencia`
union
select `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_newconsultaexternaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newconsultaexternaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newconsultaexternaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_newtraumatologiaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newtraumatologiaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newtraumatologiaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_newpediatriaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newpediatriaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newpediatriaanamesis`
union
select `cesdb_aroriginal`.`dns_newpediatriaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newpediatriaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newpediatriaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_newcardiologiaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newcardiologiaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newcardiologiaanamesis`
union
select `cesdb_aroriginal`.`dns_newcardiologiaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newcardiologiaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newcardiologiaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_newgastroenterologiaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newgastroenterologiaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newgastroenterologiaanamesis`
union
select `cesdb_aroriginal`.`dns_newgastroenterologiaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newgastroenterologiaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newgastroenterologiaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newhospitalizacionconsultaexterna`
union
select `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newprotocolooperatorio`
union
select `cesdb_aroriginal`.`dns_newepicrisisanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newepicrisisanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newepicrisisanamesis`
union
select `cesdb_aroriginal`.`dns_newinterconsulta`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newinterconsulta`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newinterconsulta`
union
select `cesdb_aroriginal`.`dns_newimagenologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newimagenologia`
union
select `cesdb_aroriginal`.`dns_newimagenologiainfo`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newimagenologiainfo`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newimagenologiainfo`
union
select `cesdb_aroriginal`.`dns_newlaboratorio`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_newlaboratorio`
union
select `cesdb_aroriginal`.`dns_anamesisexamenfisico`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_anamesisexamenfisico`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_anamesisexamenfisico`
union
select `cesdb_aroriginal`.`dns_consultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_consultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_consultaexterna`
union
select `cesdb_aroriginal`.`dns_laboratorio`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_laboratorio`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_laboratorio`
union
select `cesdb_aroriginal`.`dns_imagenologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_imagenologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_imagenologia`
union
select `cesdb_aroriginal`.`dns_odontologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_odontologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_odontologia`
union
select `cesdb_aroriginal`.`dns_fisioterapia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_fisioterapia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_fisioterapia`
union
select `cesdb_aroriginal`.`dns_enfermeria`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_enfermeria`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_enfermeria`
union
select `cesdb_aroriginal`.`dns_referencia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_referencia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_referencia`
union
select `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_subsecuenteodontologia`
union
select `cesdb_aroriginal`.`dns_interconsulta`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_interconsulta`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_interconsulta`
union
select `cesdb_aroriginal`.`dns_histopatologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_histopatologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_histopatologia`
union
select `cesdb_aroriginal`.`dns_imagenologiainfo`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_imagenologiainfo`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_imagenologiainfo`
union
select `cesdb_aroriginal`.`dns_laboratorioinforme`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_laboratorioinforme`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_laboratorioinforme`
union
select `cesdb_aroriginal`.`dns_psicologiainfantil`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_psicologiainfantil`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_psicologiainfantil`
union
select `cesdb_aroriginal`.`dns_psicologiaadolecentes`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_psicologiaadolecentes`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_psicologiaadolecentes`
union
select `cesdb_aroriginal`.`dns_oftalmologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_oftalmologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_oftalmologia`
union
select `cesdb_aroriginal`.`dns_subsecuentepsicologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_subsecuentepsicologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_subsecuentepsicologia`
union
select `cesdb_aroriginal`.`dns_ginecologia`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_ginecologia`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_ginecologia`
union
select `cesdb_aroriginal`.`dns_ginecologiaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_ginecologiaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_ginecologiaanamesis`
union
select `cesdb_aroriginal`.`dns_ginecologiaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_ginecologiaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_ginecologiaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_traumatologiaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_traumatologiaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_traumatologiaanamesis`
union
select `cesdb_aroriginal`.`dns_traumatologiaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_traumatologiaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_traumatologiaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_cardiologiaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_cardiologiaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_cardiologiaanamesis`
union
select `cesdb_aroriginal`.`dns_cardiologiaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_cardiologiaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_cardiologiaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_rehabilitacionanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_rehabilitacionanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_rehabilitacionanamesis`
union
select `cesdb_aroriginal`.`dns_rehabilitacionconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_rehabilitacionconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_rehabilitacionconsultaexterna`
union
select `cesdb_aroriginal`.`dns_pediatriaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_pediatriaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_pediatriaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_pediatriaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_pediatriaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_pediatriaanamesis`
union
select `cesdb_aroriginal`.`dns_hospitalanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_hospitalanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_hospitalanamesis`
union
select `cesdb_aroriginal`.`dns_hospitalconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_hospitalconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_hospitalconsultaexterna`
union
select `cesdb_aroriginal`.`dns_epicrisisanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_epicrisisanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_epicrisisanamesis`
union
select `cesdb_aroriginal`.`dns_epicrisisconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_epicrisisconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_epicrisisconsultaexterna`
union
select `cesdb_aroriginal`.`dns_protocolooperatorio`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_protocolooperatorio`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_protocolooperatorio`
union
select `cesdb_aroriginal`.`dns_gastroenterologiaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_gastroenterologiaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_gastroenterologiaanamesis`
union
select `cesdb_aroriginal`.`dns_gastroenterologiaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_gastroenterologiaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_gastroenterologiaconsultaexterna`
union
select `cesdb_aroriginal`.`dns_otorrinoanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_otorrinoanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_otorrinoanamesis`
union
select `cesdb_aroriginal`.`dns_otorrinoconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_otorrinoconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_otorrinoconsultaexterna`
union
select `cesdb_aroriginal`.`dns_emergenciaanamesis`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_emergenciaanamesis`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_emergenciaanamesis`
union
select `cesdb_aroriginal`.`dns_emergenciaconsultaexterna`.`clie_id` AS `clie_id`,
       `cesdb_aroriginal`.`dns_emergenciaconsultaexterna`.`usua_id` AS `usua_id`
from `cesdb_aroriginal`.`dns_emergenciaconsultaexterna`;

