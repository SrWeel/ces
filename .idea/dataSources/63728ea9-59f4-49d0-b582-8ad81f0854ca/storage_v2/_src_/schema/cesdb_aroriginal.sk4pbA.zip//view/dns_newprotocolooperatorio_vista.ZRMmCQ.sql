create definer = root@localhost view dns_newprotocolooperatorio_vista as
select `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`protoop_id`                                                  AS `protoop_id`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`centro_id`                                                   AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`clie_id`                                                     AS `clie_id`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `protoop_hc`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`protoop_fecharegistro`                                       AS `protoop_fecharegistro`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`usua_id`                                                     AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`atenc_id`                                                    AS `atenc_id`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`protoop_tblprincipal`                                        AS `protoop_tblprincipal`,
       `cesdb_aroriginal`.`dns_newprotocolooperatorio`.`protoop_idenlace`                                            AS `protoop_idenlace`
from ((((`cesdb_aroriginal`.`dns_newprotocolooperatorio` join `cesdb_aroriginal`.`app_cliente`
         on (`cesdb_aroriginal`.`dns_newprotocolooperatorio`.`clie_id` =
             `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
        on (`cesdb_aroriginal`.`dns_newprotocolooperatorio`.`centro_id` =
            `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_newprotocolooperatorio`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_newprotocolooperatorio`.`atenc_id` = `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

