create definer = root@localhost view cmb_destinocentro_vista as
select if(`cesdb_aroriginal`.`dns_centrosalud`.`centro_id` = 1, '55',
          `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`) AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre` AS `centro_nombre`
from `cesdb_aroriginal`.`dns_centrosalud`
where `cesdb_aroriginal`.`dns_centrosalud`.`centro_activosistema` = 1
union
select `cesdb_aroriginal`.`dns_destinoencentro`.`desti_id`     AS `centro_id`,
       `cesdb_aroriginal`.`dns_destinoencentro`.`desti_nombre` AS `centro_nombre`
from `cesdb_aroriginal`.`dns_destinoencentro`
where `cesdb_aroriginal`.`dns_destinoencentro`.`desti_activo` = 1;

