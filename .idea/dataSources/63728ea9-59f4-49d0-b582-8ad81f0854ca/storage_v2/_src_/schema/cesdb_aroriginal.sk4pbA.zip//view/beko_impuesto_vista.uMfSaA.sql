create definer = root@localhost view beko_impuesto_vista as
select `cesdb_aroriginal`.`beko_impuesto`.`impu_codigo` AS `hill_impucodigo`,
       `cesdb_aroriginal`.`beko_impuesto`.`impu_nombre` AS `impu_nombre`
from `cesdb_aroriginal`.`beko_impuesto`;

