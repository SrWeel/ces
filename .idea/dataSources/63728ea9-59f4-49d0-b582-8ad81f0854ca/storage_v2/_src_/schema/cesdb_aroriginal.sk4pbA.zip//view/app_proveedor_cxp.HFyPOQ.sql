create definer = root@localhost view app_proveedor_cxp as
select distinct `cesdb_aroriginal`.`app_proveedor`.`provee_id`     AS `provee_id`,
                `cesdb_aroriginal`.`app_proveedor`.`provee_nombre` AS `provee_nombre`
from (`cesdb_aroriginal`.`dns_compras` join `cesdb_aroriginal`.`app_proveedor`
      on (`cesdb_aroriginal`.`dns_compras`.`proveevar_id` = `cesdb_aroriginal`.`app_proveedor`.`provee_id`));

