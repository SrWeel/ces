create definer = root@localhost view beko_documentodetalle_factur as
select concat(`cesdb_aroriginal`.`beko_documentodetalle`.`docdet_id`, 'det') AS `data`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_codprincipal`      AS `docdet_codprincipal`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_codaux`            AS `docdet_codaux`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_descripcion`       AS `docdet_descripcion`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_cantidad`          AS `docdet_cantidad`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_preciou`           AS `docdet_preciou`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_descuento`         AS `docdet_descuento`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_total`             AS `docdet_total`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_total` *
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_porcentaje` / 100  AS `docdet_valorimpuesto`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`impu_codigo`              AS `impu_codigo`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`tari_codigo`              AS `tari_codigo`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`doccab_id`                AS `doccab_id`,
       `cesdb_aroriginal`.`beko_documentodetalle`.`docdet_porcentaje`        AS `docdet_porcentaje`,
       '1'                                                                   AS `tipol`
from `cesdb_aroriginal`.`beko_documentodetalle`
union
select concat(`cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_id`, 'mh') AS `data`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_codprincipal`     AS `docdet_codprincipal`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_codprincipal`     AS `docdet_codaux`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_descripcion`      AS `docdet_descripcion`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_cantidad`         AS `docdet_cantidad`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_preciou`          AS `docdet_preciou`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_descuento`        AS `docdet_descuento`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_total`            AS `docdet_total`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_total` *
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_porcentaje` / 100 AS `docdet_valorimpuesto`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`impumh_codigo`             AS `impu_codigo`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`tarimh_codigo`             AS `tari_codigo`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`doccab_id`                 AS `doccab_id`,
       `cesdb_aroriginal`.`beko_mhdetallefactura`.`mhdetfac_porcentaje`       AS `docdet_porcentaje`,
       '2'                                                                    AS `tipol`
from `cesdb_aroriginal`.`beko_mhdetallefactura`
union
select concat(`cesdb_aroriginal`.`lpin_cuentaventa`.`cueven_id`, 'cue')                                              AS `data`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`planv_codigoc`                                                         AS `docdet_codprincipal`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`planv_codigoc`                                                         AS `docdet_codaux`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_nombre`                                                          AS `docdet_descripcion`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`cueven_cantidad`                                                       AS `docdet_cantidad`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`cueven_preciounitario`                                                 AS `docdet_preciou`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`cueven_descuento`                                                      AS `docdet_descuento`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`cueven_subtotal`                                                       AS `docdet_total`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`cueven_subtotal` * `cesdb_aroriginal`.`beko_tarifa`.`tari_valor` /
       100                                                                                                           AS `docdet_valorimpuesto`,
       `cesdb_aroriginal`.`beko_tarifa`.`impu_codigo`                                                                AS `impu_codigo`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_codigo`                                                                AS `tari_codigo`,
       `cesdb_aroriginal`.`lpin_cuentaventa`.`doccab_id`                                                             AS `doccab_id`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_valor`                                                                 AS `docdet_porcentaje`,
       '3'                                                                                                           AS `tipol`
from ((`cesdb_aroriginal`.`lpin_cuentaventa` left join `cesdb_aroriginal`.`beko_tarifa`
       on (`cesdb_aroriginal`.`lpin_cuentaventa`.`taric_idv` =
           `cesdb_aroriginal`.`beko_tarifa`.`tari_id`)) left join `cesdb_aroriginal`.`lpin_plancuentas`
      on (`cesdb_aroriginal`.`lpin_cuentaventa`.`planv_codigoc` =
          `cesdb_aroriginal`.`lpin_plancuentas`.`planc_codigoc`));

