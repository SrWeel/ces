create definer = root@localhost view lista_formulario as
select `cesdb_aroriginal`.`dns_atencion`.`atenc_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`              AS `clie_id`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_fecharegistro` AS `anam_fecharegistro`,
       'RECEPCION'                                             AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_atencion`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                               AS `clie_id`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'CONSULTA EXTERNA'                                                       AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newhospitalizacionanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                               AS `clie_id`,
       `cesdb_aroriginal`.`dns_newhospitalizacionanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'HOSPITALIZACION'                                                        AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newhospitalizacionanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newhospitalizacionanamesis`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                          AS `clie_id`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'EMERGENCIA'                                                        AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newemergenciaanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newgastroenterologiaanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                                 AS `clie_id`,
       `cesdb_aroriginal`.`dns_newgastroenterologiaanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'GASTROENTEREOLOGIA'                                                       AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newgastroenterologiaanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newgastroenterologiaanamesis`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newlaboratorio`.`lab_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                  AS `clie_id`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`lab_fecharegistro` AS `anam_fecharegistro`,
       'LABORATORIO'                                               AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newlaboratorio`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newlaboratorio`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newcardiologiaanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                           AS `clie_id`,
       `cesdb_aroriginal`.`dns_newcardiologiaanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'CARDIOLOGIA'                                                        AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newcardiologiaanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newcardiologiaanamesis`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_histopatologia`.`histopa_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                      AS `clie_id`,
       `cesdb_aroriginal`.`dns_histopatologia`.`histopa_fecharegistro` AS `anam_fecharegistro`,
       'HISTOPATOLOGIA'                                                AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_histopatologia`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_histopatologia`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newpediatriaanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                         AS `clie_id`,
       `cesdb_aroriginal`.`dns_newpediatriaanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'PEDIATRIA'                                                        AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newpediatriaanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newpediatriaanamesis`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newinterconsulta`.`intercon_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                         AS `clie_id`,
       `cesdb_aroriginal`.`dns_newinterconsulta`.`intercon_fecharegistro` AS `anam_fecharegistro`,
       'INTERCONSULTA'                                                    AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newinterconsulta`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newinterconsulta`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                             AS `clie_id`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'TRAUMATOLOGIA'                                                        AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`clie_id`))
union
select `cesdb_aroriginal`.`dns_ginecologiaanamesis`.`anam_id`            AS `anam_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_id`                        AS `clie_id`,
       `cesdb_aroriginal`.`dns_ginecologiaanamesis`.`anam_fecharegistro` AS `anam_fecharegistro`,
       'GINECOLOGIA'                                                     AS `especialidad`
from (`cesdb_aroriginal`.`app_cliente` join `cesdb_aroriginal`.`dns_ginecologiaanamesis`
      on (`cesdb_aroriginal`.`app_cliente`.`clie_id` = `cesdb_aroriginal`.`dns_ginecologiaanamesis`.`clie_id`));

