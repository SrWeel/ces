create definer = root@localhost trigger dns_movimientoinventario_update_TRIGGER
    after update
    on dns_movimientoinventario
    for each row
BEGIN

DECLARE totalactual double;

DECLARE ingresoegreso double;

DECLARE multiplicado double; 

DECLARE saldo double;

DECLARE movimiento int;



select tipom_valor into ingresoegreso from dns_tipomovimiento where tipom_id=NEW.tipom_id;



update dns_stockactual set centro_id=NEW.centro_id,cuadrobm_id=NEW.cuadrobm_id,unid_id=NEW.unid_id,moviin_cantidadunidadconsumo=NEW.moviin_cantidadunidadconsumo,uniddesg_id=NEW.uniddesg_id,moviin_id=NEW.moviin_id,stock_cantidad=NEW.moviin_totalenunidadconsumo,stock_signo=ingresoegreso where moviin_id=NEW.moviin_id;



END;

