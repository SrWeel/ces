create definer = root@localhost view faesa_permisos_vista as
select `cesdb_aroriginal`.`faesa_permisos`.`permi_id`          AS `permi_id`,
       `cesdb_aroriginal`.`faesa_permisos`.`emp_id`            AS `emp_id`,
       `cesdb_aroriginal`.`faesa_permisos`.`usua_id`           AS `usua_id`,
       `cesdb_aroriginal`.`app_usuario`.`usua_nombre`          AS `usua_nombre`,
       `cesdb_aroriginal`.`faesa_permisos`.`permi_fecha`       AS `permi_fecha`,
       `cesdb_aroriginal`.`faesa_permisos`.`permi_observacion` AS `permi_observacion`,
       `cesdb_aroriginal`.`faesa_permisos`.`centro_id`         AS `centro_id`
from (`cesdb_aroriginal`.`faesa_permisos` join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`faesa_permisos`.`usua_id` = `cesdb_aroriginal`.`app_usuario`.`usua_id`));

