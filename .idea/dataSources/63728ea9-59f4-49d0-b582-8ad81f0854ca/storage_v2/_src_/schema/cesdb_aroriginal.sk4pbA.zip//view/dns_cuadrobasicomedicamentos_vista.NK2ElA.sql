create definer = root@localhost view dns_cuadrobasicomedicamentos_vista as
select `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_id`                         AS `cuadrobm_id`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`emp_id`                              AS `emp_id`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`categ_id`                            AS `categ_id`,
       `cesdb_aroriginal`.`dns_categoriadns`.`categ_nombre`                                    AS `categ_nombre`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_codigoatc`                  AS `cuadrobm_codigoatc`,
       if(`cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_principioactivo` = '',
          `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_nombredispositivo`,
          `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_principioactivo`)        AS `cuadrobm_principioactivo`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_nombrecomercial`            AS `cuadrobm_nombrecomercial`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_primerniveldesagregcion`    AS `cuadrobm_primerniveldesagregcion`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_tercerniveldesagregcion`    AS `cuadrobm_tercerniveldesagregcion`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_concentracion`              AS `cuadrobm_concentracion`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_preciotecho`                AS `cuadrobm_preciotecho`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_preciotechomenosporcentaje` AS `cuadrobm_preciotechomenosporcentaje`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_preciodispositivo`          AS `cuadrobm_preciodispositivo`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_saldoalafecha`              AS `cuadrobm_saldoalafecha`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_stockminimo`                AS `cuadrobm_stockminimo`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_planillable`                AS `cuadrobm_planillable`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_preciomedicamento`          AS `cuadrobm_preciomedicamento`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_codigoispol`                AS `cuadrobm_codigoispol`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_privada`                    AS `cuadrobm_privada`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_redp`                       AS `cuadrobm_redp`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_descripciontn`              AS `cuadrobm_descripciontn`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_dnivel1`                    AS `cuadrobm_dnivel1`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_dnivel3`                    AS `cuadrobm_dnivel3`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_concentraciontf`            AS `cuadrobm_concentraciontf`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_presentaciontf`             AS `cuadrobm_presentaciontf`
from (`cesdb_aroriginal`.`dns_cuadrobasicomedicamentos` join `cesdb_aroriginal`.`dns_categoriadns`
      on (`cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`categ_id` =
          `cesdb_aroriginal`.`dns_categoriadns`.`categ_id`));

