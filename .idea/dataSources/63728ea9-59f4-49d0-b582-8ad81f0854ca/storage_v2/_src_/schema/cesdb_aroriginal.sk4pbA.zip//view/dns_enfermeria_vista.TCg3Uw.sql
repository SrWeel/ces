create definer = `remote-user`@`192.168.100.10` view dns_enfermeria_vista as
select `cesdb_aroriginal`.`dns_enfermeria`.`enferm_id`                                                               AS `enferm_id`,
       `cesdb_aroriginal`.`dns_enfermeria`.`centro_id`                                                               AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_enfermeria`.`clie_id`                                                                 AS `clie_id`,
       (select `cesdb_arextension`.`dns_diagnosticoenfermeria`.`diagn_descripcion`
        from `cesdb_arextension`.`dns_diagnosticoenfermeria`
        where `cesdb_arextension`.`dns_diagnosticoenfermeria`.`enferm_enlace` =
              `cesdb_aroriginal`.`dns_enfermeria`.`enferm_enlace`
        order by `cesdb_arextension`.`dns_diagnosticoenfermeria`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `enferm_hc`,
       `cesdb_aroriginal`.`dns_enfermeria`.`enferm_fecharegistro`                                                    AS `enferm_fecharegistro`,
       `cesdb_aroriginal`.`dns_enfermeria`.`usua_id`                                                                 AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_enfermeria`.`atenc_id`                                                                AS `atenc_id`,
       `cesdb_aroriginal`.`dns_enfermeria`.`protoop_tblprincipal`                                                    AS `protoop_tblprincipal`,
       `cesdb_aroriginal`.`dns_enfermeria`.`protoop_idenlace`                                                        AS `protoop_idenlace`
from ((((`cesdb_aroriginal`.`dns_enfermeria` join `cesdb_aroriginal`.`app_cliente`
         on (`cesdb_aroriginal`.`dns_enfermeria`.`clie_id` =
             `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
        on (`cesdb_aroriginal`.`dns_enfermeria`.`centro_id` =
            `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_enfermeria`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_enfermeria`.`atenc_id` = `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

