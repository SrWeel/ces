create definer = root@localhost view dns_newtraumatologiaanamesis_vista as
select `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`anam_id`                                                   AS `anam_id`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`centro_id`                                                 AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`clie_id`                                                   AS `clie_id`,
       (select `cesdb_arextension`.`dns_newtraumatologiadiagnosticoanamnesis`.`diagn_descripcion`
        from `cesdb_arextension`.`dns_newtraumatologiadiagnosticoanamnesis`
        where (`cesdb_arextension`.`dns_newtraumatologiadiagnosticoanamnesis`.`anam_enlace` =
               `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`anam_enlace`)
        order by `cesdb_arextension`.`dns_newtraumatologiadiagnosticoanamnesis`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `anam_hc`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`anam_fecharegistro`                                        AS `anam_fecharegistro`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`usua_id`                                                   AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`atenc_id`                                                  AS `atenc_id`,
       `cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`anam_motivoconsulta`                                       AS `anam_motivoconsulta`
from ((((`cesdb_aroriginal`.`dns_newtraumatologiaanamesis` join `cesdb_aroriginal`.`app_cliente`
         on ((`cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`clie_id` =
              `cesdb_aroriginal`.`app_cliente`.`clie_id`))) join `cesdb_aroriginal`.`dns_centrosalud`
        on ((`cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`centro_id` =
             `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`))) join `cesdb_aroriginal`.`app_usuario`
       on ((`cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`usua_id` =
            `cesdb_aroriginal`.`app_usuario`.`usua_id`))) join `cesdb_aroriginal`.`dns_atencion`
      on ((`cesdb_aroriginal`.`dns_newtraumatologiaanamesis`.`atenc_id` =
           `cesdb_aroriginal`.`dns_atencion`.`atenc_id`)));

