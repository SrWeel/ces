create definer = `remote-user`@`192.168.100.10` view app_usuario_vista as
select `cesdb_aroriginal`.`app_usuario`.`usua_adm`             AS `usua_adm`,
       `cesdb_aroriginal`.`app_usuario`.`usua_id`              AS `usua_id`,
       `cesdb_aroriginal`.`app_usuario`.`emp_id`               AS `emp_id`,
       `cesdb_aroriginal`.`app_usuario`.`usua_ciruc`           AS `usua_ciruc`,
       `cesdb_aroriginal`.`app_usuario`.`usua_nombre`          AS `usua_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_apellido`        AS `usua_apellido`,
       `cesdb_aroriginal`.`app_usuario`.`usua_genero`          AS `usua_genero`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`        AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`    AS `centro_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_codigoiniciales` AS `usua_codigoiniciales`,
       (select `prof`.`prof_nombre`
        from (`cesdb_aroriginal`.`dns_gridfuncionprofesional` `grid` join `cesdb_arextension`.`dns_profesion` `prof`
              on (`grid`.`prof_id` = `prof`.`prof_id`))
        where `grid`.`usua_enlace` = `cesdb_aroriginal`.`app_usuario`.`usua_enlace`
          and `grid`.`grdifun_activo` = 1
        order by `grid`.`grdifun_fecharegistro` desc
        limit 1)                                               AS `usua_formaciondelprofesional`,
       `conved`.`conve_nombre`                                 AS `conve_nombre`
from ((`cesdb_aroriginal`.`app_usuario` left join `cesdb_aroriginal`.`dns_centrosalud`
       on (`cesdb_aroriginal`.`app_usuario`.`centro_id` =
           `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) left join `cesdb_arextension`.`dns_convenios` `conved`
      on (`cesdb_aroriginal`.`app_usuario`.`conve_id` = `conved`.`conve_id`))
order by `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre` desc;

