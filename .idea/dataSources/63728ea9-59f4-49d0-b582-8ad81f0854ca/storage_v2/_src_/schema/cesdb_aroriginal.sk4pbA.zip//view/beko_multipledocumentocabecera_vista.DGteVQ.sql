create definer = root@localhost view beko_multipledocumentocabecera_vista as
select `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_id`                                            AS `doccab_id`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_ndocumento`                                    AS `doccab_ndocumento`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_rucci_cliente`                                 AS `doccab_rucci_cliente`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_nombrerazon_cliente`                           AS `doccab_nombrerazon_cliente`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_apellidorazon_cliente`                         AS `doccab_apellidorazon_cliente`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_fechaemision_cliente`                          AS `doccab_fechaemision_cliente`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_estadosri`                                     AS `doccab_estadosri`,
       if(`cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_anulado` = 1, 'ANULADO',
          '')                                                                                                     AS `doccab_anulado`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_motivoanulado`                                 AS `doccab_motivoanulado`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_total`                                         AS `doccab_total`,
       date_format(`cesdb_aroriginal`.`beko_multipledocumentocabecera`.`doccab_fechaemision_cliente`,
                   '%Y-%m-%d')                                                                                    AS `fecha_dia`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`emp_id`                                               AS `emp_id`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`usua_id`                                              AS `usua_id`,
       `cesdb_aroriginal`.`beko_multipledocumentocabecera`.`centro_id`                                            AS `centro_id`
from `cesdb_aroriginal`.`beko_multipledocumentocabecera`;

