create definer = root@localhost view beko_recibocabecera_vista as
select `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_id`                                            AS `doccab_id`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_ndocumento`                                    AS `doccab_ndocumento`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_observacion`                                   AS `doccab_observacion`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_rucci_cliente`                                 AS `doccab_rucci_cliente`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_nombrerazon_cliente`                           AS `doccab_nombrerazon_cliente`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_apellidorazon_cliente`                         AS `doccab_apellidorazon_cliente`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_fechaemision_cliente`                          AS `doccab_fechaemision_cliente`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_estadosri`                                     AS `doccab_estadosri`,
       if(`cesdb_aroriginal`.`beko_recibocabecera`.`doccab_anulado` = 1, 'ANULADO',
          '')                                                                                          AS `doccab_anulado`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_motivoanulado`                                 AS `doccab_motivoanulado`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`doccab_total`                                         AS `doccab_total`,
       date_format(`cesdb_aroriginal`.`beko_recibocabecera`.`doccab_fechaemision_cliente`, '%Y-%m-%d') AS `fecha_dia`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`emp_id`                                               AS `emp_id`,
       `cesdb_aroriginal`.`beko_recibocabecera`.`usua_id`                                              AS `usua_id`
from `cesdb_aroriginal`.`beko_recibocabecera`;

