create definer = root@localhost view vista_clinica_horarios as
select `cesdb_aroriginal`.`clinica_horarios`.`horario_id`                                                            AS `horario_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `medico`,
       `cesdb_aroriginal`.`dns_listadia`.`dia_nombre`                                                                AS `dia_nombre`,
       `cesdb_aroriginal`.`clinica_horarios`.`horario_hora`                                                          AS `horario_hora`,
       `cesdb_aroriginal`.`clinica_horarios`.`horario_horafin`                                                       AS `horario_horafin`,
       `cesdb_aroriginal`.`gogess_sino`.`etiqueta`                                                                   AS `etiqueta`
from (((`cesdb_aroriginal`.`app_usuario` join `cesdb_aroriginal`.`clinica_horarios`
        on (`cesdb_aroriginal`.`clinica_horarios`.`usua_id` =
            `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_listadia`
       on (`cesdb_aroriginal`.`clinica_horarios`.`dia_id` =
           `cesdb_aroriginal`.`dns_listadia`.`dia_id`)) left join `cesdb_aroriginal`.`gogess_sino`
      on (`cesdb_aroriginal`.`clinica_horarios`.`horario_activo` = `cesdb_aroriginal`.`gogess_sino`.`value`));

