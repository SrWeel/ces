create definer = `remote-user`@`192.168.100.10` view dns_compras_vista as
select `cesdb_aroriginal`.`dns_compras`.`compra_id`                                      AS `compra_id`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_ruc`                                   AS `provee_ruc`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_cedula`                                AS `provee_cedula`,
       `cesdb_aroriginal`.`dns_compras`.`compra_autorizacion`                            AS `compra_autorizacion`,
       `cesdb_aroriginal`.`dns_compras`.`emp_id`                                         AS `emp_id`,
       `cesdb_aroriginal`.`app_empresa`.`emp_nombre`                                     AS `emp_nombre`,
       `cesdb_aroriginal`.`dns_compras`.`proveevar_id`                                   AS `proveevar_id`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_nombre`                                AS `provee_nombre`,
       `cesdb_aroriginal`.`dns_compras`.`compra_nfactura`                                AS `compra_nfactura`,
       `cesdb_aroriginal`.`dns_compras`.`compra_fecharegistro`                           AS `compra_fecharegistro`,
       `cesdb_aroriginal`.`dns_compras`.`compra_valorfactura`                            AS `compra_valorfactura`,
       `cesdb_aroriginal`.`dns_compras`.`compra_fecha`                                   AS `compra_fecha`,
       `cesdb_aroriginal`.`dns_compras`.`compra_descripcion`                             AS `compra_descripcion`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_nombrecomercial`                       AS `provee_nombrecomercial`,
       `cesdb_aroriginal`.`dns_compras`.`compra_subtotaliva`                             AS `compra_subtotaliva`,
       `cesdb_aroriginal`.`dns_compras`.`compra_subtotalceroiva`                         AS `compra_subtotalceroiva`,
       `cesdb_aroriginal`.`dns_compras`.`compra_descuento`                               AS `compra_descuento`,
       `cesdb_aroriginal`.`dns_compras`.`compra_iva`                                     AS `compra_iva`,
       `cesdb_aroriginal`.`dns_compras`.`compra_total`                                   AS `compra_total`,
       if(`cesdb_aroriginal`.`dns_compras`.`compra_pagacajachica` = 1, 'CAJA CHICA', '') AS `compra_pagacajachica`,
       if(`cesdb_aroriginal`.`dns_compras`.`compra_anulado` = 1, 'ANULADO', '')          AS `compra_anulado`,
       round(`cesdb_aroriginal`.`dns_compras`.`compra_subtotaliva` +
             `cesdb_aroriginal`.`dns_compras`.`compra_subtotalceroiva`, 2)               AS `neto`,
       round((select sum(`cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_valorretenido`) AS `tiva`
              from ((`cesdb_aroriginal`.`comprobante_retencion_cab` join `cesdb_aroriginal`.`comprobante_retencion_detalle`
                     on (`cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_id` =
                         `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretcab_id`)) left join `cesdb_aroriginal`.`comprobante_retencion_gasto`
                    on (`cesdb_aroriginal`.`comprobante_retencion_detalle`.`porcentaje_id` =
                        `cesdb_aroriginal`.`comprobante_retencion_gasto`.`porcentaje_id`))
              where `cesdb_aroriginal`.`comprobante_retencion_gasto`.`compretdet_gasto` = 1
                and `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id` =
                    `cesdb_aroriginal`.`dns_compras`.`compra_id`
              group by `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id`), 2)   AS `retnasume`,
       round((select sum(`cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_valorretenido`) AS `tiva`
              from (`cesdb_aroriginal`.`comprobante_retencion_cab` join `cesdb_aroriginal`.`comprobante_retencion_detalle`
                    on (`cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_id` =
                        `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretcab_id`))
              where `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id` =
                    `cesdb_aroriginal`.`dns_compras`.`compra_id`
                and `cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_anulado` = 0
              group by `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id`), 2)   AS `totalret`,
       if(round(if(`cesdb_aroriginal`.`dns_compras`.`compra_anulado` = '1', 0, if(
               `cesdb_aroriginal`.`dns_compras`.`tipdoc_id` = '9' and
               `cesdb_aroriginal`.`dns_compras`.`compra_nummodif` <> '', '0',
               round(`cesdb_aroriginal`.`dns_compras`.`compra_total`, 2) - if(round(
                                                                                      (select sum(`cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_valorretenido`) AS `tiva`
                                                                                       from (`cesdb_aroriginal`.`comprobante_retencion_cab` join `cesdb_aroriginal`.`comprobante_retencion_detalle`
                                                                                             on (`cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_id` =
                                                                                                 `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretcab_id`))
                                                                                       where
                                                                                           `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_gasto` =
                                                                                           0
                                                                                         and
                                                                                           `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id` =
                                                                                           `cesdb_aroriginal`.`dns_compras`.`compra_id`
                                                                                         and `cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_anulado` = 0
                                                                                       group by `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id`),
                                                                                      2) is null, 0, round(
                                                                                      (select sum(`cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_valorretenido`) AS `tiva`
                                                                                       from (`cesdb_aroriginal`.`comprobante_retencion_cab` join `cesdb_aroriginal`.`comprobante_retencion_detalle`
                                                                                             on (`cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_id` =
                                                                                                 `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretcab_id`))
                                                                                       where
                                                                                           `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_gasto` =
                                                                                           0
                                                                                         and
                                                                                           `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id` =
                                                                                           `cesdb_aroriginal`.`dns_compras`.`compra_id`
                                                                                         and `cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_anulado` = 0
                                                                                       group by `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id`),
                                                                                      2)) -
               if(round((select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `anticipo`
                         from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                               on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                   `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                         where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                               `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2) is null, 0,
                  round((select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `anticipo`
                         from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                               on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                   `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                         where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                               `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2)) -
               round(if(round((select sum(`cesdb_arextension`.`lpin_crucecuentas`.`crucue_valorpago`) AS `anticipo`
                               from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucecuentas`
                                     on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                         `cesdb_arextension`.`lpin_crucecuentas`.`crudoc_enlace`))
                               where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                     `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2) is null, 0,
                        round((select sum(`cesdb_arextension`.`lpin_crucecuentas`.`crucue_valorpago`) AS `anticipo`
                               from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucecuentas`
                                     on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                         `cesdb_arextension`.`lpin_crucecuentas`.`crudoc_enlace`))
                               where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                     `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2)), 2) -
               round(if(round((select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                               from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                     on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                         `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                               where `cesdb_aroriginal`.`lpin_cobropagodetalle`.`compracp_id` =
                                     `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2) is null, 0,
                        round((select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                               from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                     on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                         `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                               where `cesdb_aroriginal`.`lpin_cobropagodetalle`.`compracp_id` =
                                     `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2)), 2) -
               round(if((select sum(`nc`.`compra_total`) AS `total`
                         from `cesdb_aroriginal`.`dns_compras` `nc`
                         where `nc`.`tipdoc_id` = 9
                           and `nc`.`compra_nummodif` = `cesdb_aroriginal`.`dns_compras`.`compra_nfactura`
                           and `nc`.`proveevar_id` = `cesdb_aroriginal`.`dns_compras`.`proveevar_id`) is null, 0,
                        (select sum(`nc`.`compra_total`) AS `total`
                         from `cesdb_aroriginal`.`dns_compras` `nc`
                         where `nc`.`tipdoc_id` = 9
                           and `nc`.`compra_nummodif` = `cesdb_aroriginal`.`dns_compras`.`compra_nfactura`
                           and `nc`.`proveevar_id` = `cesdb_aroriginal`.`dns_compras`.`proveevar_id`)), 2) -
               if(round((select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                         from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                               on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                   `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                         where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                               `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2) is null, 0,
                  round((select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                         from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                               on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                   `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                         where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                               `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2)) -
               if(round((select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                         from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                               on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                   `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                         where `cesdb_arextension`.`lpin_crucedetalle`.`crudet_documento` =
                               `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2) is null, 0,
                  round((select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                         from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                               on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                   `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                         where `cesdb_arextension`.`lpin_crucedetalle`.`crudet_documento` =
                               `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2)))), 2) = '-0', 0, round(
                  if(`cesdb_aroriginal`.`dns_compras`.`compra_anulado` = '1', 0, if(
                          `cesdb_aroriginal`.`dns_compras`.`tipdoc_id` = '9' and
                          `cesdb_aroriginal`.`dns_compras`.`compra_nummodif` <> '', '0',
                          round(`cesdb_aroriginal`.`dns_compras`.`compra_total`, 2) - if(round(
                                                                                                 (select sum(`cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_valorretenido`) AS `tiva`
                                                                                                  from (`cesdb_aroriginal`.`comprobante_retencion_cab` join `cesdb_aroriginal`.`comprobante_retencion_detalle`
                                                                                                        on (`cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_id` =
                                                                                                            `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretcab_id`))
                                                                                                  where
                                                                                                      `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_gasto` =
                                                                                                      0
                                                                                                    and
                                                                                                      `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id` =
                                                                                                      `cesdb_aroriginal`.`dns_compras`.`compra_id`
                                                                                                    and `cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_anulado` = 0
                                                                                                  group by `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id`),
                                                                                                 2) is null, 0, round(
                                                                                                 (select sum(`cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_valorretenido`) AS `tiva`
                                                                                                  from (`cesdb_aroriginal`.`comprobante_retencion_cab` join `cesdb_aroriginal`.`comprobante_retencion_detalle`
                                                                                                        on (`cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_id` =
                                                                                                            `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretcab_id`))
                                                                                                  where
                                                                                                      `cesdb_aroriginal`.`comprobante_retencion_detalle`.`compretdet_gasto` =
                                                                                                      0
                                                                                                    and
                                                                                                      `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id` =
                                                                                                      `cesdb_aroriginal`.`dns_compras`.`compra_id`
                                                                                                    and `cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_anulado` = 0
                                                                                                  group by `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id`),
                                                                                                 2)) - if(round(
                                                                                                                  (select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `anticipo`
                                                                                                                   from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                                                                                                                         on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                             `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                                                                                                                   where
                                                                                                                       `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                                                                                                       `cesdb_aroriginal`.`dns_compras`.`compra_id`),
                                                                                                                  2) is null,
                                                                                                          0, round(
                                                                                                                  (select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `anticipo`
                                                                                                                   from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                                                                                                                         on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                             `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                                                                                                                   where
                                                                                                                       `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                                                                                                       `cesdb_aroriginal`.`dns_compras`.`compra_id`),
                                                                                                                  2)) -
                          round(if(round(
                                           (select sum(`cesdb_arextension`.`lpin_crucecuentas`.`crucue_valorpago`) AS `anticipo`
                                            from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucecuentas`
                                                  on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                      `cesdb_arextension`.`lpin_crucecuentas`.`crudoc_enlace`))
                                            where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                                  `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2) is null, 0, round(
                                           (select sum(`cesdb_arextension`.`lpin_crucecuentas`.`crucue_valorpago`) AS `anticipo`
                                            from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucecuentas`
                                                  on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                      `cesdb_arextension`.`lpin_crucecuentas`.`crudoc_enlace`))
                                            where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                                  `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2)), 2) - round(if(
                                                                                                                         round(
                                                                                                                                 (select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                                                                                                                                  from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                                                                                                                        on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                                                                                                                            `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                                                                                                                                  where
                                                                                                                                      `cesdb_aroriginal`.`lpin_cobropagodetalle`.`compracp_id` =
                                                                                                                                      `cesdb_aroriginal`.`dns_compras`.`compra_id`),
                                                                                                                                 2) is null,
                                                                                                                         0,
                                                                                                                         round(
                                                                                                                                 (select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                                                                                                                                  from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                                                                                                                        on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                                                                                                                            `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                                                                                                                                  where
                                                                                                                                      `cesdb_aroriginal`.`lpin_cobropagodetalle`.`compracp_id` =
                                                                                                                                      `cesdb_aroriginal`.`dns_compras`.`compra_id`),
                                                                                                                                 2)),
                                                                                                                 2) -
                          round(if((select sum(`nc`.`compra_total`) AS `total`
                                    from `cesdb_aroriginal`.`dns_compras` `nc`
                                    where `nc`.`tipdoc_id` = 9
                                      and `nc`.`compra_nummodif` = `cesdb_aroriginal`.`dns_compras`.`compra_nfactura`
                                      and `nc`.`proveevar_id` = `cesdb_aroriginal`.`dns_compras`.`proveevar_id`) is null,
                                   0, (select sum(`nc`.`compra_total`) AS `total`
                                       from `cesdb_aroriginal`.`dns_compras` `nc`
                                       where `nc`.`tipdoc_id` = 9
                                         and `nc`.`compra_nummodif` = `cesdb_aroriginal`.`dns_compras`.`compra_nfactura`
                                         and `nc`.`proveevar_id` = `cesdb_aroriginal`.`dns_compras`.`proveevar_id`)),
                                2) - if(round(
                                                (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                                 from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                                       on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                           `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                                 where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                                       `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2) is null, 0,
                                        round(
                                                (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                                 from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                                       on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                           `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                                 where `cesdb_aroriginal`.`lpin_crucedocumentos`.`compracr_id` =
                                                       `cesdb_aroriginal`.`dns_compras`.`compra_id`), 2)) - if(round(
                                                                                                                       (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                                                                                                        from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                                                                                                              on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                                  `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                                                                                                        where
                                                                                                                            `cesdb_arextension`.`lpin_crucedetalle`.`crudet_documento` =
                                                                                                                            `cesdb_aroriginal`.`dns_compras`.`compra_id`),
                                                                                                                       2) is null,
                                                                                                               0, round(
                                                                                                                       (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                                                                                                        from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                                                                                                              on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                                  `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                                                                                                        where
                                                                                                                            `cesdb_arextension`.`lpin_crucedetalle`.`crudet_documento` =
                                                                                                                            `cesdb_aroriginal`.`dns_compras`.`compra_id`),
                                                                                                                       2)))),
                  2))                                                                    AS `saldo`,
       (select `cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_estadosri`
        from `cesdb_aroriginal`.`comprobante_retencion_cab`
        where `cesdb_aroriginal`.`comprobante_retencion_cab`.`compra_id` = `cesdb_aroriginal`.`dns_compras`.`compra_id`
          and `cesdb_aroriginal`.`comprobante_retencion_cab`.`compretcab_anulado` = 0
        limit 1)                                                                         AS `sriretencion`,
       `cesdb_aroriginal`.`dns_tipodocumentogeneral`.`tipdoc_nombre`                     AS `tipdoc_nombre`,
       'dns_compras'                                                                     AS `tabla_comp`,
       `cesdb_aroriginal`.`dns_compras`.`tipdoc_id`                                      AS `tipdoc_id`,
       `cesdb_aroriginal`.`dns_compras`.`compra_estadosri`                               AS `compra_estadosri`,
       `cesdb_aroriginal`.`dns_compras`.`compra_vencimiento`                             AS `compra_vencimiento`,
       `cesdb_aroriginal`.`dns_compras`.`usua_id`                                        AS `usuarc_id`
from (((`cesdb_aroriginal`.`dns_compras` join `cesdb_aroriginal`.`app_proveedor`
        on (`cesdb_aroriginal`.`dns_compras`.`proveevar_id` =
            `cesdb_aroriginal`.`app_proveedor`.`provee_id`)) join `cesdb_aroriginal`.`app_empresa`
       on (`cesdb_aroriginal`.`dns_compras`.`emp_id` =
           `cesdb_aroriginal`.`app_empresa`.`emp_id`)) left join `cesdb_aroriginal`.`dns_tipodocumentogeneral`
      on (`cesdb_aroriginal`.`dns_compras`.`tipdoc_id` = `cesdb_aroriginal`.`dns_tipodocumentogeneral`.`tipdoc_id`));

