create definer = root@localhost view dns_referencia_vista as
select `cesdb_aroriginal`.`dns_referencia`.`referencia_id`                                                           AS `referencia_id`,
       `cesdb_aroriginal`.`dns_referencia`.`centro_id`                                                               AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_referencia`.`clie_id`                                                                 AS `clie_id`,
       (select `cesdb_aroriginal`.`dns_diagnosticoreferencia`.`diagn_descripcion`
        from `cesdb_aroriginal`.`dns_diagnosticoreferencia`
        where `cesdb_aroriginal`.`dns_diagnosticoreferencia`.`referencia_enlace` =
              `cesdb_aroriginal`.`dns_referencia`.`referencia_enlace`
        order by `cesdb_aroriginal`.`dns_diagnosticoreferencia`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `referencia_hc`,
       `cesdb_aroriginal`.`dns_referencia`.`referencia_fecharegistro`                                                AS `referencia_fecharegistro`,
       `cesdb_aroriginal`.`dns_referencia`.`usua_id`                                                                 AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_referencia`.`atenc_id`                                                                AS `atenc_id`
from ((((`cesdb_aroriginal`.`dns_referencia` join `cesdb_aroriginal`.`app_cliente`
         on (`cesdb_aroriginal`.`dns_referencia`.`clie_id` =
             `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
        on (`cesdb_aroriginal`.`dns_referencia`.`centro_id` =
            `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_referencia`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_referencia`.`atenc_id` = `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

