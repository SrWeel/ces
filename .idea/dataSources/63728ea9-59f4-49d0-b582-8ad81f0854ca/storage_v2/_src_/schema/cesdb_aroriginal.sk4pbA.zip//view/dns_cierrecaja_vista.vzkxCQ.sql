create definer = `remote-user`@`192.168.100.10` view dns_cierrecaja_vista as
select `cesdb_aroriginal`.`dns_cierrecaja`.`cierr_id`                            AS `cierr_id`,
       `cesdb_aroriginal`.`dns_cierrecaja`.`emp_id`                              AS `emp_id`,
       `cesdb_aroriginal`.`dns_cierrecaja`.`centro_id`                           AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                      AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_cierrecaja`.`cierr_fecha`                         AS `cierr_fecha`,
       `cesdb_aroriginal`.`dns_cierrecaja`.`cierr_fechafin`                      AS `cierr_fechafin`,
       if(`cesdb_aroriginal`.`dns_cierrecaja`.`cierr_estado` = 1, 'CERRADO', '') AS `cierr_estado`,
       `crr`.`ctpc_nombre`                                                       AS `ctpc_nombre`,
       `cesdb_aroriginal`.`dns_cierrecaja`.`usua_id`                             AS `usua_id`
from ((`cesdb_aroriginal`.`dns_cierrecaja` join `cesdb_aroriginal`.`dns_centrosalud`
       on (`cesdb_aroriginal`.`dns_cierrecaja`.`centro_id` =
           `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_arcombos`.`app_cmbtipocierre` `crr`
      on (`crr`.`ctpc_id` = `cesdb_aroriginal`.`dns_cierrecaja`.`ctpc_id`));

