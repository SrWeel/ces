create definer = root@localhost trigger dns_movimientoinventario_del_TRIGGER
    after delete
    on dns_movimientoinventario
    for each row
BEGIN



    DELETE FROM dns_stockactual WHERE moviin_id=OLD.moviin_id;

 

END;

