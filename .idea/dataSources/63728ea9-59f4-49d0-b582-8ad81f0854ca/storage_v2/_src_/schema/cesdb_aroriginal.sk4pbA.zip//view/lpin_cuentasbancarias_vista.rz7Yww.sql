create definer = root@localhost view lpin_cuentasbancarias_vista as
select `cesdb_aroriginal`.`lpin_cuentasbancarias`.`cuentb_id`             AS `cuentb_id`,
       `cesdb_aroriginal`.`lpin_entidadesfinancieras`.`entif_nombre`      AS `entif_nombre`,
       `cesdb_aroriginal`.`lpin_cuentasbancarias`.`cuentb_cuentacontable` AS `cuentb_cuentacontable`
from (`cesdb_aroriginal`.`lpin_cuentasbancarias` join `cesdb_aroriginal`.`lpin_entidadesfinancieras`
      on (`cesdb_aroriginal`.`lpin_cuentasbancarias`.`entif_id` =
          `cesdb_aroriginal`.`lpin_entidadesfinancieras`.`entif_id`));

