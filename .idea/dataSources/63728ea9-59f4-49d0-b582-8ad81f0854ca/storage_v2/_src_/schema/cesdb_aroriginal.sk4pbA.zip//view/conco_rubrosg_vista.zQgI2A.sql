create definer = root@localhost view conco_rubrosg_vista as
select `cesdb_aroriginal`.`conco_rubrosg`.`rubrg_id`                         AS `rubrg_id`,
       `cesdb_aroriginal`.`conco_rubrosg`.`emp_id`                           AS `emp_id`,
       `cesdb_aroriginal`.`conco_rubrosg`.`tiporub_id`                       AS `tiporub_id`,
       `cesdb_aroriginal`.`conco_tiporub`.`tiporub_nombre`                   AS `tiporub_nombre`,
       `cesdb_aroriginal`.`conco_rubrosg`.`rubrg_nombre`                     AS `rubrg_nombre`,
       if(`cesdb_aroriginal`.`conco_rubrosg`.`rubrg_activo` = 1, 'SI', 'NO') AS `rubrg_activonom`,
       `cesdb_aroriginal`.`conco_rubrosg`.`rubrg_fecharegistro`              AS `rubrg_fecharegistro`
from (`cesdb_aroriginal`.`conco_rubrosg` join `cesdb_aroriginal`.`conco_tiporub`
      on (`cesdb_aroriginal`.`conco_rubrosg`.`tiporub_id` = `cesdb_aroriginal`.`conco_tiporub`.`tiporub_id`));

