create definer = `remote-user`@`192.168.100.10` view dns_newconsultaexternaanamesis_vista as
select `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`anam_id`                                                 AS `anam_id`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`centro_id`                                               AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`clie_id`                                                 AS `clie_id`,
       (select `cesdb_arextension`.`dns_newconsultaexternadiagnosticoanamnesis`.`diagn_descripcion`
        from `cesdb_arextension`.`dns_newconsultaexternadiagnosticoanamnesis`
        where `cesdb_arextension`.`dns_newconsultaexternadiagnosticoanamnesis`.`anam_enlace` =
              `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`anam_enlace`
        order by `cesdb_arextension`.`dns_newconsultaexternadiagnosticoanamnesis`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `anam_hc`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`anam_fecharegistro`                                      AS `anam_fecharegistro`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`usua_id`                                                 AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`atenc_id`                                                AS `atenc_id`,
       `cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`anam_motivoconsulta`                                     AS `anam_motivoconsulta`
from ((((`cesdb_aroriginal`.`dns_newconsultaexternaanamesis` join `cesdb_aroriginal`.`app_cliente`
         on (`cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`clie_id` =
             `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
        on (`cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`centro_id` =
            `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_newconsultaexternaanamesis`.`atenc_id` =
          `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

