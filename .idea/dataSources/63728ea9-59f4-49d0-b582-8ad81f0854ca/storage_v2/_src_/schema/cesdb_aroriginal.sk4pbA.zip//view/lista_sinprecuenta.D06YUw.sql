create definer = root@localhost view lista_sinprecuenta as
select `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`                     AS `doccab_id`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`tipocmp_codigo`                AS `tipocmp_codigo`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_ndocumento`             AS `doccab_ndocumento`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_rucci_cliente`          AS `doccab_rucci_cliente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_nombrerazon_cliente`    AS `doccab_nombrerazon_cliente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_apellidorazon_cliente`  AS `doccab_apellidorazon_cliente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_identificacionpaciente` AS `doccab_identificacionpaciente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_total`                  AS `doccab_total`,
       (select count(0) AS `producto_precuenta`
        from `cesdb_aroriginal`.`beko_documentodetalle`
        where `cesdb_aroriginal`.`beko_documentodetalle`.`doccab_id` =
              `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`
          and `cesdb_aroriginal`.`beko_documentodetalle`.`precu_id` > 0)           AS `cprecuenta1`,
       (select count(0) AS `producto_precuenta`
        from `cesdb_aroriginal`.`beko_mhdetallefactura`
        where `cesdb_aroriginal`.`beko_mhdetallefactura`.`doccab_id` =
              `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`
          and `cesdb_aroriginal`.`beko_mhdetallefactura`.`precu_id` > 0)           AS `cprecuenta2`
from `cesdb_aroriginal`.`beko_documentocabecera`;

