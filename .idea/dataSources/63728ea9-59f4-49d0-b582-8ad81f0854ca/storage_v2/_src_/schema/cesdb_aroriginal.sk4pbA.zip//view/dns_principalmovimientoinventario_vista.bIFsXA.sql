create definer = root@localhost view dns_principalmovimientoinventario_vista as
select `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`moviin_id`                   AS `moviin_id`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`cuadrobm_id`                 AS `cuadrobm_id`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`centro_id`                   AS `centro_id`,
       `cesdb_aroriginal`.`dns_tipomovimiento`.`tipom_nombre`                               AS `tipom_nombre`,
       `cesdb_aroriginal`.`dns_motivomovimiento`.`tipomov_nombre`                           AS `tipomov_nombre`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`moviin_nlote`                AS `moviin_nlote`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`moviin_fechadecaducidad`     AS `moviin_fechadecaducidad`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`moviin_fecharegistro`        AS `moviin_fecharegistro`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`centrorecibe_cantidad`       AS `centrorecibe_cantidad`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`moviin_totalenunidadconsumo` AS `moviin_totalenunidadconsumo`,
       concat(`cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_principioactivo`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_nombredispositivo`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_primerniveldesagregcion`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_presentacion`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_concentracion`)   AS `nombre_med`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`categ_id`                         AS `categ_id`,
       `cesdb_aroriginal`.`dns_principalmovimientoinventario`.`compra_id`                   AS `compra_id`
from (((`cesdb_aroriginal`.`dns_principalmovimientoinventario` join `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`
        on (`cesdb_aroriginal`.`dns_principalmovimientoinventario`.`cuadrobm_id` =
            `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_id`)) left join `cesdb_aroriginal`.`dns_tipomovimiento`
       on (`cesdb_aroriginal`.`dns_principalmovimientoinventario`.`tipom_id` =
           `cesdb_aroriginal`.`dns_tipomovimiento`.`tipom_id`)) left join `cesdb_aroriginal`.`dns_motivomovimiento`
      on (`cesdb_aroriginal`.`dns_principalmovimientoinventario`.`tipomov_id` =
          `cesdb_aroriginal`.`dns_motivomovimiento`.`tipomov_id`));

