create definer = root@localhost view dns_descargofunjibles_vista as
select `cesdb_aroriginal`.`dns_descargofunjibles`.`descragfunj_id`                                                   AS `descragfunj_id`,
       `cesdb_aroriginal`.`dns_descargofunjibles`.`centro_id`                                                        AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_descargofunjibles`.`usua_id`                                                          AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `nombreusuario`,
       `cesdb_aroriginal`.`dns_descargofunjibles`.`descragfunj_fecharegistro`                                        AS `descragfunj_fecharegistro`,
       `cesdb_aroriginal`.`dns_descargofunjibles`.`descragfunj_observacion`                                          AS `descragfunj_observacion`
from ((`cesdb_aroriginal`.`dns_descargofunjibles` join `cesdb_aroriginal`.`dns_centrosalud`
       on (`cesdb_aroriginal`.`dns_descargofunjibles`.`centro_id` =
           `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`dns_descargofunjibles`.`usua_id` = `cesdb_aroriginal`.`app_usuario`.`usua_id`));

