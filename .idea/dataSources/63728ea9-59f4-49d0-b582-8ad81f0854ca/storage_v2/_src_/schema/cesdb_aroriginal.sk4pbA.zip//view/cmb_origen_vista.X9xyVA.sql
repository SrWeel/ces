create definer = root@localhost view cmb_origen_vista as
select `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`     AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre` AS `centro_nombre`
from `cesdb_aroriginal`.`dns_centrosalud`
where `cesdb_aroriginal`.`dns_centrosalud`.`centro_activosistema` = 1;

