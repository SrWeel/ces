create definer = root@localhost view lpin_comprobantecontable_asiento as
select `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_id`              AS `comcont_id`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_fecha`           AS `comcont_fecha`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_concepto`        AS `comcont_concepto`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_numeroc`         AS `comcont_numeroc`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_tabla`           AS `comcont_tabla`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_idtabla`         AS `comcont_idtabla`,
       (select count(0) AS `totalcp`
        from `cesdb_aroriginal`.`app_movimientobancos`
        where `cesdb_aroriginal`.`app_movimientobancos`.`movban_id` =
              `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_idtabla`) AS `totalmoivmiento`
from `cesdb_aroriginal`.`lpin_comprobantecontable`
where `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_tabla` = 'app_movimientobancos'
order by (select count(0) AS `totalcp`
          from `cesdb_aroriginal`.`app_movimientobancos`
          where `cesdb_aroriginal`.`app_movimientobancos`.`movban_id` =
                `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_idtabla`);

