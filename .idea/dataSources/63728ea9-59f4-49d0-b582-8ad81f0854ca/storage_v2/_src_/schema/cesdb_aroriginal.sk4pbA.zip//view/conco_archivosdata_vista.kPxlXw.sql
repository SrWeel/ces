create definer = root@localhost view conco_archivosdata_vista as
select `cesdb_aroriginal`.`conco_archivosdata`.`archdt_id`            AS `archdt_id`,
       `cesdb_aroriginal`.`conco_archivosdata`.`tiparch_id`           AS `tiparch_id`,
       `cesdb_aroriginal`.`cmb_tipoarchivo`.`tiparch_nombre`          AS `tiparch_nombre`,
       `cesdb_aroriginal`.`conco_archivosdata`.`archdt_anio`          AS `archdt_anio`,
       `cesdb_aroriginal`.`conco_archivosdata`.`archdt_mes`           AS `archdt_mes`,
       `cesdb_aroriginal`.`conco_archivosdata`.`usua_id`              AS `usua_id`,
       `cesdb_aroriginal`.`conco_archivosdata`.`emp_id`               AS `emp_id`,
       `cesdb_aroriginal`.`conco_archivosdata`.`archdt_fecharegistro` AS `archdt_fecharegistro`
from (`cesdb_aroriginal`.`conco_archivosdata` join `cesdb_aroriginal`.`cmb_tipoarchivo`
      on (`cesdb_aroriginal`.`conco_archivosdata`.`tiparch_id` = `cesdb_aroriginal`.`cmb_tipoarchivo`.`tiparch_id`));

