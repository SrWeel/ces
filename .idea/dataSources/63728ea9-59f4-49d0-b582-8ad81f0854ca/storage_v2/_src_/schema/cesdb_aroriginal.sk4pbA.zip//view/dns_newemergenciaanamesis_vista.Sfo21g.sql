create definer = `remote-user`@`192.168.100.10` view dns_newemergenciaanamesis_vista as
select `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`anam_id`                                                      AS `anam_id`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`centro_id`                                                    AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`clie_id`                                                      AS `clie_id`,
       (select `cesdb_arextension`.`dns_newemergenciadiagnosticoanamnesis`.`diagn_descripcion`
        from `cesdb_arextension`.`dns_newemergenciadiagnosticoanamnesis`
        where `cesdb_arextension`.`dns_newemergenciadiagnosticoanamnesis`.`anam_enlace` =
              `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`anam_enlace`
        order by `cesdb_arextension`.`dns_newemergenciadiagnosticoanamnesis`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `anam_hc`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`anam_fecharegistro`                                           AS `anam_fecharegistro`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`usua_id`                                                      AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`atenc_id`                                                     AS `atenc_id`,
       `cesdb_aroriginal`.`dns_newemergenciaanamesis`.`anam_motivoconsulta`                                          AS `anam_motivoconsulta`
from ((((`cesdb_aroriginal`.`dns_newemergenciaanamesis` join `cesdb_aroriginal`.`app_cliente`
         on (`cesdb_aroriginal`.`dns_newemergenciaanamesis`.`clie_id` =
             `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
        on (`cesdb_aroriginal`.`dns_newemergenciaanamesis`.`centro_id` =
            `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_newemergenciaanamesis`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_newemergenciaanamesis`.`atenc_id` = `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

