create definer = root@localhost view efacsistema_genpuntoemision_nc as
select `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_id`     AS `pemisionnc_id`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`estab_id`        AS `estabnc_id`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_num`    AS `pemisionnc_num`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_inicia` AS `pemisionnc_inicia`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_sino`   AS `pemisionnc_sino`
from `cesdb_aroriginal`.`efacsistema_genpuntoemision`;

