create definer = root@localhost view dns_odontologia_vista as
select `cesdb_aroriginal`.`dns_odontologia`.`odonto_id`                                                              AS `odonto_id`,
       `cesdb_aroriginal`.`dns_odontologia`.`centro_id`                                                              AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_odontologia`.`clie_id`                                                                AS `clie_id`,
       (select `cesdb_aroriginal`.`dns_diagnosticoodontologia`.`diagn_descripcion`
        from `cesdb_aroriginal`.`dns_diagnosticoodontologia`
        where `cesdb_aroriginal`.`dns_diagnosticoodontologia`.`odonto_enlace` =
              `cesdb_aroriginal`.`dns_odontologia`.`odonto_enlace`
        order by `cesdb_aroriginal`.`dns_diagnosticoodontologia`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_odontologia`.`odonto_fecharegistro`                                                   AS `odonto_fecharegistro`,
       `cesdb_aroriginal`.`dns_odontologia`.`usua_id`                                                                AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_odontologia`.`atenc_id`                                                               AS `atenc_id`,
       `cesdb_aroriginal`.`dns_odontologia`.`odonto_motivoconsulta`                                                  AS `odonto_motivoconsulta`
from (((`cesdb_aroriginal`.`dns_odontologia` join `cesdb_aroriginal`.`app_cliente`
        on (`cesdb_aroriginal`.`dns_odontologia`.`clie_id` =
            `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
       on (`cesdb_aroriginal`.`dns_odontologia`.`centro_id` =
           `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`dns_odontologia`.`usua_id` = `cesdb_aroriginal`.`app_usuario`.`usua_id`));

