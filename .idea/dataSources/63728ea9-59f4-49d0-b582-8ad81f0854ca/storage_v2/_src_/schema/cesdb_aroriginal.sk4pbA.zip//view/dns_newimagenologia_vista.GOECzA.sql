create definer = root@localhost view dns_newimagenologia_vista as
select `cesdb_aroriginal`.`dns_newimagenologia`.`imgag_id`                                                           AS `imgag_id`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`centro_id`                                                          AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`clie_id`                                                            AS `clie_id`,
       (select `cesdb_aroriginal`.`dns_diagnosticonewimagensolicitud`.`diagn_descripcion`
        from `cesdb_aroriginal`.`dns_diagnosticonewimagensolicitud`
        where `cesdb_aroriginal`.`dns_diagnosticonewimagensolicitud`.`imgag_enlace` =
              `cesdb_aroriginal`.`dns_newimagenologia`.`imgag_enlace`
        order by `cesdb_aroriginal`.`dns_diagnosticonewimagensolicitud`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `imgag_hc`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`imgag_fecharegistro`                                                AS `imgag_fecharegistro`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`usua_id`                                                            AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`atenc_id`                                                           AS `atenc_id`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`imgag_idexterno`                                                    AS `imgag_idexterno`,
       `cesdb_aroriginal`.`dns_newimagenologia`.`imgag_tablaexterno`                                                 AS `imgag_tablaexterno`
from ((((`cesdb_aroriginal`.`dns_newimagenologia` join `cesdb_aroriginal`.`app_cliente`
         on (`cesdb_aroriginal`.`dns_newimagenologia`.`clie_id` =
             `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
        on (`cesdb_aroriginal`.`dns_newimagenologia`.`centro_id` =
            `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_newimagenologia`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) left join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_newimagenologia`.`atenc_id` = `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

