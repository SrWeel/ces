create definer = root@localhost view cuentas_listado_control as
select `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_id`                       AS `comcont_id`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`tipoa_id`                         AS `tipoa_id`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_fecha`                    AS `comcont_fecha`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_concepto`                 AS `comcont_concepto`,
       round((select sum(`cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_debe`) AS `debe`
              from `cesdb_aroriginal`.`lpin_detallecomprobantecontable`
              where `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`comcont_enlace` =
                    `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_enlace`), 2) AS `debe`,
       round((select sum(`cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_haber`) AS `haber`
              from `cesdb_aroriginal`.`lpin_detallecomprobantecontable`
              where `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`comcont_enlace` =
                    `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_enlace`), 2) AS `haber`
from `cesdb_aroriginal`.`lpin_comprobantecontable`;

