create definer = root@localhost view dns_movimientoinventario_vista as
select `cesdb_aroriginal`.`dns_movimientoinventario`.`moviin_id`                          AS `moviin_id`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`cuadrobm_id`                        AS `cuadrobm_id`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`centro_id`                          AS `centro_id`,
       `cesdb_aroriginal`.`dns_tipomovimiento`.`tipom_nombre`                             AS `tipom_nombre`,
       `cesdb_aroriginal`.`dns_motivomovimiento`.`tipomov_nombre`                         AS `tipomov_nombre`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`moviin_nlote`                       AS `moviin_nlote`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`moviin_fechadecaducidad`            AS `moviin_fechadecaducidad`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`moviin_fecharegistro`               AS `moviin_fecharegistro`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`centrorecibe_cantidad`              AS `centrorecibe_cantidad`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`moviin_totalenunidadconsumo`        AS `moviin_totalenunidadconsumo`,
       concat(`cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_principioactivo`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_nombredispositivo`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_primerniveldesagregcion`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_presentacion`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_concentracion`) AS `nombre_med`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`categ_id`                       AS `categ_id`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`compra_id`                          AS `compra_id`,
       `cesdb_aroriginal`.`dns_movimientoinventario`.`perioac_id`                         AS `perioac_id`
from (((`cesdb_aroriginal`.`dns_movimientoinventario` join `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`
        on (`cesdb_aroriginal`.`dns_movimientoinventario`.`cuadrobm_id` =
            `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_id`)) left join `cesdb_aroriginal`.`dns_tipomovimiento`
       on (`cesdb_aroriginal`.`dns_movimientoinventario`.`tipom_id` =
           `cesdb_aroriginal`.`dns_tipomovimiento`.`tipom_id`)) left join `cesdb_aroriginal`.`dns_motivomovimiento`
      on (`cesdb_aroriginal`.`dns_movimientoinventario`.`tipomov_id` =
          `cesdb_aroriginal`.`dns_motivomovimiento`.`tipomov_id`));

