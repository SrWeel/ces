create definer = root@localhost view repite_cedula as
select count(`cesdb_aroriginal`.`app_proveedor`.`provee_cedula`) AS `num`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_cedula`        AS `provee_cedula`
from `cesdb_aroriginal`.`app_proveedor`
group by `cesdb_aroriginal`.`app_proveedor`.`provee_cedula`
having count(`cesdb_aroriginal`.`app_proveedor`.`provee_cedula`) > 1
   and `cesdb_aroriginal`.`app_proveedor`.`provee_cedula` <> ''
order by count(`cesdb_aroriginal`.`app_proveedor`.`provee_cedula`) desc;

