create definer = root@localhost view lpin_formapagoventa_vista as
select sum(`cesdb_aroriginal`.`lpin_formapagoventa`.`frmpven_plazo`)                                      AS `totaldias`,
       date_format(`cesdb_aroriginal`.`beko_documentocabecera`.`doccab_fechaemision_cliente`,
                   '%Y-%m-%d')                                                                            AS `doccab_fechaemision_cliente`,
       `cesdb_aroriginal`.`lpin_formapagoventa`.`doccab_id`                                               AS `doccab_id`
from (`cesdb_aroriginal`.`lpin_formapagoventa` join `cesdb_aroriginal`.`beko_documentocabecera`
      on (`cesdb_aroriginal`.`lpin_formapagoventa`.`doccab_id` =
          `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`))
group by `cesdb_aroriginal`.`lpin_formapagoventa`.`doccab_id`;

