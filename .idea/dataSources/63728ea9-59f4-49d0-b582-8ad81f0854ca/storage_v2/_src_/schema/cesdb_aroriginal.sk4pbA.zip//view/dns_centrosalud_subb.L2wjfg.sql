create definer = root@localhost view dns_centrosalud_subb as
select `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`     AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre` AS `centro_nombre`
from `cesdb_aroriginal`.`dns_centrosalud`
where `cesdb_aroriginal`.`dns_centrosalud`.`centro_activosistema` = 1
  and `cesdb_aroriginal`.`dns_centrosalud`.`centro_id` <> 1
union
select `cesdb_aroriginal`.`dns_destino`.`desti_id`     AS `centro_id`,
       `cesdb_aroriginal`.`dns_destino`.`desti_nombre` AS `centro_nombre`
from `cesdb_aroriginal`.`dns_destino`
where `cesdb_aroriginal`.`dns_destino`.`desti_activo` = 1;

