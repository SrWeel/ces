create definer = root@localhost trigger dns_principalmovimientoinventario_del_TRIGGER
    after delete
    on dns_principalmovimientoinventario
    for each row
BEGIN



    DELETE FROM dns_principalstockactual WHERE moviin_id=OLD.moviin_id;

 

END;

