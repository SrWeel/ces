create definer = root@localhost view validabodega as
select `tbl1`.`moviin_id`                                       AS `moviin_id`,
       `tbl1`.`cuadrobm_id`                                     AS `cuadrobm_id`,
       `tbl1`.`moviin_totalenunidadconsumo`                     AS `moviin_totalenunidadconsumo`,
       (select sum(`tbl2`.`moviin_totalenunidadconsumo`)
        from `cesdb_aroriginal`.`dns_principalmovimientoinventario` `tbl2`
        where `tbl2`.`tipom_id` = 2
          and `tbl2`.`moviintranscent_id` = `tbl1`.`moviin_id`) AS `consumido`
from `cesdb_aroriginal`.`dns_principalmovimientoinventario` `tbl1`
where `tbl1`.`tipom_id` = 1;

