create definer = root@localhost view dns_actividadoperativa_vista as
select `cesdb_aroriginal`.`dns_actividadoperativa`.`activiope_id`                                                    AS `activiope_id`,
       `cesdb_aroriginal`.`dns_actividadoperativa`.`centro_id`                                                       AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_id`                                                                    AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `nombreus`,
       `cesdb_aroriginal`.`dns_actividadoperativa`.`activiope_fecharegistro`                                         AS `activiope_fecharegistro`,
       `cesdb_aroriginal`.`dns_actividadoperativa`.`activiope_observacion`                                           AS `activiope_observacion`
from ((`cesdb_aroriginal`.`dns_actividadoperativa` join `cesdb_aroriginal`.`dns_centrosalud`
       on (`cesdb_aroriginal`.`dns_actividadoperativa`.`centro_id` =
           `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`dns_actividadoperativa`.`usua_id` = `cesdb_aroriginal`.`app_usuario`.`usua_id`));

