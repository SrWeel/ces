create definer = root@localhost view efacsistema_genpuntoemision_retencion as
select `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_id`     AS `pemisionr_id`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`estab_id`        AS `estabr_id`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_num`    AS `pemisionr_num`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_inicia` AS `pemisionr_inicia`,
       `cesdb_aroriginal`.`efacsistema_genpuntoemision`.`pemision_sino`   AS `pemisionr_sino`
from `cesdb_aroriginal`.`efacsistema_genpuntoemision`;

