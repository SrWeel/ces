create definer = root@localhost view faesa_biometrico_vista as
select `cesdb_aroriginal`.`faesa_biometrico`.`bio_id`    AS `bio_id`,
       `cesdb_aroriginal`.`app_usuario`.`usua_nombre`    AS `usua_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_apellido`  AS `usua_apellido`,
       `cesdb_aroriginal`.`faesa_biometrico`.`bio_fecha` AS `bio_fecha`,
       `cesdb_aroriginal`.`faesa_biometrico`.`bio_hora`  AS `bio_hora`,
       `cesdb_aroriginal`.`faesa_biometrico`.`bio_marca` AS `bio_marca`
from (`cesdb_aroriginal`.`faesa_biometrico` join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`faesa_biometrico`.`bio_codigousuario` =
          `cesdb_aroriginal`.`app_usuario`.`usua_codigobiometrico`));

