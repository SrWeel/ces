create definer = root@localhost view conco_generarroles_vista as
select `cesdb_aroriginal`.`conco_generarroles`.`genr_id`            AS `genr_id`,
       `cesdb_aroriginal`.`conco_generarroles`.`emp_id`             AS `emp_id`,
       `cesdb_aroriginal`.`conco_generarroles`.`genr_anio`          AS `genr_anio`,
       `cesdb_aroriginal`.`conco_generarroles`.`genr_mes`           AS `genr_mes`,
       `cesdb_aroriginal`.`conco_generarroles`.`genr_fechacierre`   AS `genr_fechacierre`,
       `cesdb_aroriginal`.`conco_generarroles`.`genr_fecharegistro` AS `genr_fecharegistro`,
       `cesdb_aroriginal`.`app_mes`.`mes_nombre`                    AS `mes_nombre`
from (`cesdb_aroriginal`.`conco_generarroles` join `cesdb_aroriginal`.`app_mes`
      on (`cesdb_aroriginal`.`conco_generarroles`.`genr_mes` = `cesdb_aroriginal`.`app_mes`.`mes_id`));

