create definer = root@localhost view faesa_horasentrada_vista as
select `cesdb_aroriginal`.`faesa_horasentrada`.`horae_id`          AS `horae_id`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`polasis_id`        AS `polasis_id`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`usua_id`           AS `usua_id`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`horae_motivo`      AS `horae_motivo`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`horae_desde`       AS `horae_desde`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`horae_hasta`       AS `horae_hasta`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`horae_horaentrada` AS `horae_horaentrada`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`horae_horasalida`  AS `horae_horasalida`,
       `cesdb_aroriginal`.`faesa_horasentrada`.`horae_indefinido`  AS `horae_indefinido`,
       `cesdb_aroriginal`.`app_usuario`.`usua_nombre`              AS `usua_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_apellido`            AS `usua_apellido`
from (`cesdb_aroriginal`.`faesa_horasentrada` join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`faesa_horasentrada`.`usua_id` = `cesdb_aroriginal`.`app_usuario`.`usua_id`));

