create definer = root@localhost view conco_asiganrubro_vista as
select `cesdb_aroriginal`.`conco_asiganrubro`.`asigr_id`                                                             AS `asigr_id`,
       `cesdb_aroriginal`.`conco_asiganrubro`.`emp_id`                                                               AS `emp_id`,
       `cesdb_aroriginal`.`conco_asiganrubro`.`usua_id`                                                              AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `nom_cliente`,
       `cesdb_aroriginal`.`conco_rubrosg`.`rubrg_id`                                                                 AS `rubrg_id`,
       `cesdb_aroriginal`.`conco_rubrosg`.`rubrg_nombre`                                                             AS `rubrg_nombre`,
       `cesdb_aroriginal`.`conco_asiganrubro`.`asigr_observacion`                                                    AS `asigr_observacion`,
       if(`cesdb_aroriginal`.`conco_asiganrubro`.`asigr_activo` = 1, 'SI',
          'NO')                                                                                                      AS `asigr_activonom`,
       `cesdb_aroriginal`.`conco_asiganrubro`.`asigr_fecharegistro`                                                  AS `asigr_fecharegistro`
from ((`cesdb_aroriginal`.`conco_asiganrubro` join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`conco_asiganrubro`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`conco_rubrosg`
      on (`cesdb_aroriginal`.`conco_asiganrubro`.`rubrg_id` = `cesdb_aroriginal`.`conco_rubrosg`.`rubrg_id`));

