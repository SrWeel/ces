create definer = root@localhost view repite_ruc as
select count(`cesdb_aroriginal`.`app_proveedor`.`provee_ruc`) AS `num`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_ruc`        AS `provee_ruc`
from `cesdb_aroriginal`.`app_proveedor`
group by `cesdb_aroriginal`.`app_proveedor`.`provee_ruc`
having count(`cesdb_aroriginal`.`app_proveedor`.`provee_ruc`) > 1
   and `cesdb_aroriginal`.`app_proveedor`.`provee_ruc` <> ''
order by count(`cesdb_aroriginal`.`app_proveedor`.`provee_ruc`) desc;

