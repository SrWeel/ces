create definer = root@localhost view lpin_detallecomprobantecontable2_vista as
select `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_id`                                  AS `detcc_id`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`comcont_enlace`                            AS `comcont_enlace`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_cuentacontable`                      AS `detcc_cuentacontable`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_descricpion`                         AS `detcc_descricpion`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_referencia`                          AS `detcc_referencia`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_entidad`                             AS `detcc_entidad`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_debe`                                AS `detcc_debe`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_haber`                               AS `detcc_haber`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`centcost_id`                               AS `centcost_id`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`usua_id`                                   AS `usua_id`,
       `cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_fecharegistro`                       AS `detcc_fecharegistro`,
       concat(`cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_cuentacontable`,
              '.')                                                                                      AS `detcc_cuentacontablep`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_fecha`                                    AS `comcont_fecha`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_anulado`                                  AS `comcont_anulado`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`tipoa_id`                                         AS `tipoa_id`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_id`                                       AS `comcont_id`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_numeroc`                                  AS `comcont_numeroc`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_concepto`                                 AS `comcont_concepto`,
       `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_inicial`                                  AS `comcont_inicial`,
       `SPLIT_STR`(`cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`detcc_cuentacontable`, '.', 1) AS `codcuenta`
from (`cesdb_aroriginal`.`lpin_detallecomprobantecontable` join `cesdb_aroriginal`.`lpin_comprobantecontable`
      on (`cesdb_aroriginal`.`lpin_detallecomprobantecontable`.`comcont_enlace` =
          `cesdb_aroriginal`.`lpin_comprobantecontable`.`comcont_enlace`));

