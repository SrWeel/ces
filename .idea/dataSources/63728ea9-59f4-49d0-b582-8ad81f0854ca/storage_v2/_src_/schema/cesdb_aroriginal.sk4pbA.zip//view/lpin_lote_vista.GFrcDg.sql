create definer = root@localhost view lpin_lote_vista as
select `cesdb_aroriginal`.`lpin_lote`.`lottar_id`                        AS `lottar_id`,
       `cesdb_aroriginal`.`lpin_lote`.`lottar_recap`                     AS `lottar_recap`,
       `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_fechaemision` AS `crpadet_fechaemision`,
       `cesdb_aroriginal`.`lpin_lote`.`lottar_fechai`                    AS `lottar_fechai`,
       `cesdb_aroriginal`.`lpin_lote`.`lottar_fechaf`                    AS `lottar_fechaf`,
       `cesdb_aroriginal`.`lpin_lote`.`usua_id`                          AS `usua_id`,
       `cesdb_aroriginal`.`lpin_lote`.`redc_id`                          AS `redc_id`,
       `cesdb_aroriginal`.`lpin_redcobro`.`redc_nombre`                  AS `redc_nombre`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_ndocumento`   AS `doccab_ndocumento`,
       `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`  AS `saldo`,
       `cesdb_aroriginal`.`lpin_cobropago`.`crb_ncomprobante`            AS `crb_ncomprobante`
from ((((`cesdb_aroriginal`.`lpin_lote` left join `cesdb_aroriginal`.`lpin_cobropago`
         on (`cesdb_aroriginal`.`lpin_lote`.`lottar_id` =
             `cesdb_aroriginal`.`lpin_cobropago`.`lote_id`)) join `cesdb_aroriginal`.`lpin_cobropagodetalle`
        on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
            `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`)) left join `cesdb_aroriginal`.`beko_documentocabecera`
       on (`cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id` =
           `cesdb_aroriginal`.`lpin_cobropagodetalle`.`doccabcp_id`)) left join `cesdb_aroriginal`.`lpin_redcobro`
      on (`cesdb_aroriginal`.`lpin_lote`.`redc_id` = `cesdb_aroriginal`.`lpin_redcobro`.`redc_id`));

