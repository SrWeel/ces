create definer = `remote-user`@`192.168.100.10` view app_anticipos_vista as
select `cesdb_aroriginal`.`app_anticipos`.`anti_id`                                                                  AS `anti_id`,
       `cesdb_aroriginal`.`app_anticipos`.`proveeanti_id`                                                            AS `proveeanti_id`,
       `cesdb_aroriginal`.`app_anticipos`.`anti_fechaemision`                                                        AS `anti_fechaemision`,
       `cesdb_aroriginal`.`app_anticipos`.`anti_descripcion`                                                         AS `anti_descripcion`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_nombre`                                                            AS `provee_nombre`,
       (select sum(`cesdb_aroriginal`.`lpin_movanticipos`.`movanti_monto`) AS `total`
        from `cesdb_aroriginal`.`lpin_movanticipos`
        where `cesdb_aroriginal`.`lpin_movanticipos`.`anti_enlace` =
              `cesdb_aroriginal`.`app_anticipos`.`anti_enlace`)                                                      AS `total`,
       (select sum(`cesdb_aroriginal`.`lpin_movanticipos`.`movanti_monto`) AS `total`
        from `cesdb_aroriginal`.`lpin_movanticipos`
        where `cesdb_aroriginal`.`lpin_movanticipos`.`anti_enlace` = `cesdb_aroriginal`.`app_anticipos`.`anti_enlace`) -
       if(round((select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `anticipo`
                 from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                       on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                           `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                 where `cesdb_arextension`.`lpin_cruceanticipos`.`cruant_anticipo` =
                       `cesdb_aroriginal`.`app_anticipos`.`anti_id`), 2) is null, 0,
          round((select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `anticipo`
                 from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                       on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                           `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                 where `cesdb_arextension`.`lpin_cruceanticipos`.`cruant_anticipo` =
                       `cesdb_aroriginal`.`app_anticipos`.`anti_id`),
                2))                                                                                                  AS `saldo`
from (`cesdb_aroriginal`.`app_anticipos` left join `cesdb_aroriginal`.`app_proveedor`
      on (`cesdb_aroriginal`.`app_anticipos`.`proveeanti_id` = `cesdb_aroriginal`.`app_proveedor`.`provee_id`));

