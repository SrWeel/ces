create definer = root@localhost view dns_newemergenciaconsultaexterna_vista as
select `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`conext_id`                                             AS `conext_id`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `npaciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `atenc_hc`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`conext_fechar`                                         AS `conext_fechar`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`conext_horar`                                          AS `conext_horar`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`conext_notasdeevolucion`                               AS `conext_notasdeevolucion`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`conext_prescripciones`                                 AS `conext_prescripciones`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`conext_fecharegistro`                                  AS `conext_fecharegistro`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`atenc_id`                                              AS `atenc_id`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`clie_id`                                               AS `clie_id`,
       `cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`anam_id`                                               AS `anam_id`
from ((`cesdb_aroriginal`.`dns_newemergenciaconsultaexterna` left join `cesdb_aroriginal`.`dns_atencion`
       on (`cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`atenc_id` =
           `cesdb_aroriginal`.`dns_atencion`.`atenc_id`)) join `cesdb_aroriginal`.`app_cliente`
      on (`cesdb_aroriginal`.`dns_newemergenciaconsultaexterna`.`clie_id` =
          `cesdb_aroriginal`.`app_cliente`.`clie_id`));

