create definer = root@localhost view dns_subsecuenteodontologia_vista as
select `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`subsecodont_id`                                              AS `subsecodont_id`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`centro_id`                                                   AS `centro_id`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`clie_id`                                                     AS `clie_id`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `npaciente`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                                                                  AS `atenc_hc`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`atenc_id`                                                    AS `atenc_id`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`usua_id`                                                     AS `usua_id`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`subsecodont_fecharegistro`                                   AS `subsecodont_fecharegistro`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`subsecodont_diagnosticoscomplicaciones`                      AS `subsecodont_diagnosticoscomplicaciones`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`subsecodont_procedimientos`                                  AS `subsecodont_procedimientos`,
       `cesdb_aroriginal`.`dns_subsecuenteodontologia`.`odonto_id`                                                   AS `odonto_id`
from ((`cesdb_aroriginal`.`dns_subsecuenteodontologia` join `cesdb_aroriginal`.`app_cliente`
       on (`cesdb_aroriginal`.`dns_subsecuenteodontologia`.`clie_id` =
           `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_atencion`
      on (`cesdb_aroriginal`.`dns_subsecuenteodontologia`.`atenc_id` = `cesdb_aroriginal`.`dns_atencion`.`atenc_id`));

