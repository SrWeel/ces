create definer = root@localhost view efacsistema_genestablecimiento_retencion as
select `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`estab_id`       AS `estabr_id`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`emp_id`         AS `emp_id`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`estab_codigo`   AS `estabr_codigo`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`estab_estado`   AS `estabr_estado`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`centro_id`      AS `centro_id`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`tipocmp_codigo` AS `tipocmp_codigo`
from `cesdb_aroriginal`.`efacsistema_genestablecimiento`
where `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`tipocmp_codigo` = '07';

