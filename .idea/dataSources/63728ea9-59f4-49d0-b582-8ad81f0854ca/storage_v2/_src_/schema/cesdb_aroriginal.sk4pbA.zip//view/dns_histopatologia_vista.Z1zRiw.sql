create definer = root@localhost view dns_histopatologia_vista as
select `cesdb_aroriginal`.`dns_histopatologia`.`histopa_id`                                                          AS `histopa_id`,
       `cesdb_aroriginal`.`dns_histopatologia`.`centro_id`                                                           AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_histopatologia`.`clie_id`                                                             AS `clie_id`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       (select `cesdb_aroriginal`.`dns_diagnosticohistopatologia`.`diagn_descripcion`
        from `cesdb_aroriginal`.`dns_diagnosticohistopatologia`
        where `cesdb_aroriginal`.`dns_diagnosticohistopatologia`.`histopa_enlace` =
              `cesdb_aroriginal`.`dns_histopatologia`.`histopa_enlace`
        order by `cesdb_aroriginal`.`dns_diagnosticohistopatologia`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       `cesdb_aroriginal`.`dns_histopatologia`.`histopa_hc`                                                          AS `histopa_hc`,
       `cesdb_aroriginal`.`dns_histopatologia`.`usua_id`                                                             AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_histopatologia`.`histopa_fecharegistro`                                               AS `histopa_fecharegistro`,
       `cesdb_aroriginal`.`dns_histopatologia`.`histopa_fechasolicitud`                                              AS `histopa_fechasolicitud`,
       `cesdb_aroriginal`.`dns_histopatologia`.`atenc_id`                                                            AS `atenc_id`
from (((`cesdb_aroriginal`.`dns_histopatologia` join `cesdb_aroriginal`.`app_cliente`
        on (`cesdb_aroriginal`.`dns_histopatologia`.`clie_id` =
            `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
       on (`cesdb_aroriginal`.`dns_histopatologia`.`centro_id` =
           `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
      on (`cesdb_aroriginal`.`dns_histopatologia`.`usua_id` = `cesdb_aroriginal`.`app_usuario`.`usua_id`));

