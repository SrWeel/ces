create definer = `remote-user`@`192.168.100.10` view app_movimientobancos_vista as
select `cesdb_aroriginal`.`app_movimientobancos`.`movban_id`                       AS `movban_id`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_nombre`                          AS `provee_nombre`,
       `cmbbanc`.`tmv_nombre`                                                      AS `tmv_nombre`,
       `detabanco`.`detmov_nombre`                                                 AS `detmov_nombre`,
       `cesdb_aroriginal`.`app_movimientobancos`.`movban_descripcion`              AS `movban_descripcion`,
       `cesdb_aroriginal`.`app_movimientobancos`.`movban_fechaemision`             AS `movban_fechaemision`,
       round((select sum(`cesdb_aroriginal`.`lpin_movbancos`.`movbanc_monto`) AS `total_ingresado`
              from `cesdb_aroriginal`.`lpin_movbancos`
              where `cesdb_aroriginal`.`lpin_movbancos`.`movban_enlace` =
                    `cesdb_aroriginal`.`app_movimientobancos`.`movban_enlace`), 2) AS `movban_total`,
       `cesdb_aroriginal`.`app_movimientobancos`.`movban_comprobante`              AS `movban_comprobante`
from ((((`cesdb_aroriginal`.`app_movimientobancos` join `cesdb_arcombos`.`cmb_tipomovbancos` `tipmoiv`
         on (`cesdb_aroriginal`.`app_movimientobancos`.`movban_tipotransaccion` =
             `tipmoiv`.`movban_id`)) join `cesdb_arcombos`.`cmb_tipomovbanco` `cmbbanc`
        on (`cesdb_aroriginal`.`app_movimientobancos`.`tmv_id` =
            `cmbbanc`.`tmv_id`)) join `cesdb_arcombos`.`cmd_tipodetallemovbancos` `detabanco`
       on (`cesdb_aroriginal`.`app_movimientobancos`.`detmov_id` =
           `detabanco`.`detmov_id`)) join `cesdb_aroriginal`.`app_proveedor`
      on (`cesdb_aroriginal`.`app_movimientobancos`.`proveemovban_id` =
          `cesdb_aroriginal`.`app_proveedor`.`provee_id`));

