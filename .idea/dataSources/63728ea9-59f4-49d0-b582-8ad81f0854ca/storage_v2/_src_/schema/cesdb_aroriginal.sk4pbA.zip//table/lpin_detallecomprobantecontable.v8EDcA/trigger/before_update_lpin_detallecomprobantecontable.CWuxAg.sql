create definer = root@localhost trigger before_update_lpin_detallecomprobantecontable
    before update
    on lpin_detallecomprobantecontable
    for each row
BEGIN

    SET NEW.detcc_cuentacontablepg = concat(NEW.detcc_cuentacontable,'.');

	SET NEW.codcuentapg = SPLIT_STR(NEW.detcc_cuentacontable,'.',1);

END;

