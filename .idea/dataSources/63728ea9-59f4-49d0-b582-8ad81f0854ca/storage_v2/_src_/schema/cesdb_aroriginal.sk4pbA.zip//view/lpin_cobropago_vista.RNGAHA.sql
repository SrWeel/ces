create definer = root@localhost view lpin_cobropago_vista as
select `cesdb_aroriginal`.`lpin_cobropago`.`crb_id`             AS `crb_id`,
       `cesdb_aroriginal`.`lpin_cobropago`.`crb_fecha`          AS `crb_fecha`,
       `cesdb_aroriginal`.`lpin_ttransac`.`ttra_nombre`         AS `ttra_nombre`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_nombre`       AS `provee_nombre`,
       `cesdb_aroriginal`.`lpin_cobropago`.`crb_cuenta`         AS `crb_cuenta`,
       `cesdb_aroriginal`.`lpin_cobropago`.`crb_ncomprobante`   AS `crb_ncomprobante`,
       (select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
        from `cesdb_aroriginal`.`lpin_cobropagodetalle`
        where `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace` =
              `cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace`) AS `valort`,
       `cesdb_aroriginal`.`lpin_cobropago`.`doccab_id`          AS `doccab_id`,
       `cesdb_aroriginal`.`lpin_cobropago`.`compra_id`          AS `compra_id`,
       `lpin_cuentasbancarias_vista`.`entif_nombre`             AS `entif_nombre`
from (((`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_ttransac`
        on (`cesdb_aroriginal`.`lpin_cobropago`.`ttra_id` =
            `cesdb_aroriginal`.`lpin_ttransac`.`ttra_id`)) join `cesdb_aroriginal`.`app_proveedor`
       on (`cesdb_aroriginal`.`lpin_cobropago`.`proveep_id` =
           `cesdb_aroriginal`.`app_proveedor`.`provee_id`)) left join `cesdb_aroriginal`.`lpin_cuentasbancarias_vista`
      on (`cesdb_aroriginal`.`lpin_cobropago`.`cuentb_id` = `lpin_cuentasbancarias_vista`.`cuentb_id`));

