create definer = root@localhost view dns_unidad_vista as
select `cesdb_aroriginal`.`dns_unidad`.`unid_id`     AS `uniddesg_id`,
       `cesdb_aroriginal`.`dns_unidad`.`unid_nombre` AS `uniddesg_nombre`
from `cesdb_aroriginal`.`dns_unidad`;

