create definer = root@localhost view dns_visitadomiciliaria_vista as
select `cesdb_aroriginal`.`dns_visitadomiciliaria`.`vidomici_id`            AS `vidomici_id`,
       `cesdb_aroriginal`.`dns_visitadomiciliaria`.`centro_id`              AS `centro_id`,
       `cesdb_aroriginal`.`dns_visitadomiciliaria`.`usua_id`                AS `usua_id`,
       `cesdb_aroriginal`.`app_usuario`.`usua_nombre`                       AS `usua_nombre`,
       `cesdb_aroriginal`.`app_usuario`.`usua_apellido`                     AS `usua_apellido`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                 AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_visitadomiciliaria`.`vidomici_fecharegistro` AS `vidomici_fecharegistro`,
       `cesdb_aroriginal`.`dns_visitadomiciliaria`.`vidomici_observacion`   AS `vidomici_observacion`
from ((`cesdb_aroriginal`.`dns_visitadomiciliaria` join `cesdb_aroriginal`.`app_usuario`
       on (`cesdb_aroriginal`.`dns_visitadomiciliaria`.`usua_id` =
           `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
      on (`cesdb_aroriginal`.`dns_visitadomiciliaria`.`centro_id` = `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`));

