create definer = root@localhost view comprobar_sistema as
select `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_total`      AS `doccab_total`,
       (select sum(`cesdb_aroriginal`.`beko_documentodetalle`.`docdet_total`) AS `dtotal`
        from `cesdb_aroriginal`.`beko_documentodetalle`
        where `cesdb_aroriginal`.`beko_documentodetalle`.`doccab_id` =
              `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`) AS `Name_exp_2`
from `cesdb_aroriginal`.`beko_documentocabecera`;

