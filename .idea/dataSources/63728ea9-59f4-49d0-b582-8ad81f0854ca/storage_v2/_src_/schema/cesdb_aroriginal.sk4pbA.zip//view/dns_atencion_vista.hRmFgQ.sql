create definer = root@localhost view dns_atencion_vista as
select `cesdb_aroriginal`.`dns_atencion`.`atenc_id`                   AS `atenc_id`,
       `cesdb_aroriginal`.`dns_atencion`.`clie_id`                    AS `clie_id`,
       `cesdb_aroriginal`.`dns_atencion`.`emp_id`                     AS `emp_id`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_hc`                   AS `atenc_hc`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_fecharegistro`        AS `atenc_fecharegistro`,
       `cesdb_aroriginal`.`app_cliente`.`clie_nombre`                 AS `clie_nombre`,
       `cesdb_aroriginal`.`app_cliente`.`clie_apellido`               AS `clie_apellido`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`           AS `centro_nombre`,
       `cesdb_aroriginal`.`faesa_estadoatencion`.`estaatenc_nombre`   AS `estaatenc_nombre`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_estadopsicologia`     AS `atenc_estadopsicologia`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_estadoodontologia`    AS `atenc_estadoodontologia`,
       `cesdb_aroriginal`.`dns_atencion`.`atenc_estadorehabilitacion` AS `atenc_estadorehabilitacion`,
       `cesdb_aroriginal`.`dns_atencion`.`centro_id`                  AS `centro_id`
from (((`cesdb_aroriginal`.`dns_atencion` join `cesdb_aroriginal`.`app_cliente`
        on (`cesdb_aroriginal`.`dns_atencion`.`clie_id` =
            `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
       on (`cesdb_aroriginal`.`dns_atencion`.`centro_id` =
           `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) left join `cesdb_aroriginal`.`faesa_estadoatencion`
      on (`cesdb_aroriginal`.`dns_atencion`.`estaatenc_id` = `cesdb_aroriginal`.`faesa_estadoatencion`.`estaatenc_id`));

