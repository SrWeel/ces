create definer = root@localhost view cmb_dns_cuadrobasicomedicamentos as
select `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_id`                    AS `cuadrobm_id`,
       concat(`cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_principioactivo`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_nombredispositivo`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_primerniveldesagregcion`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_presentacion`, ' ',
              `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_concentracion`) AS `nombre_med`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`categ_id`                       AS `categ_id`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_codigoatc`             AS `cuadrobm_codigoatc`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`subcateg_id`                    AS `subcateg_id`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_partidapresupuest`     AS `cuadrobm_partidapresupuest`
from `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`
where `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_historial` = 0;

