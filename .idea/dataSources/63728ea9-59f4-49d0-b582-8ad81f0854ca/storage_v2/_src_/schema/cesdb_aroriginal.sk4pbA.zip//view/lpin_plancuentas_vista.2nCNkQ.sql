create definer = root@localhost view lpin_plancuentas_vista as
select `cesdb_aroriginal`.`lpin_plancuentas`.`planc_id`                   AS `planc_id`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_codigo`               AS `planc_codigo`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_codigoc`              AS `planc_codigoc`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_nombre`               AS `planc_nombre`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_codigoplan`           AS `planc_codigoplan`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_signo`                AS `planc_signo`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`plancs_id`                  AS `plancs_id`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`tcuenta_id`                 AS `tcuenta_id`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_code1`                AS `planc_code1`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_code2`                AS `planc_code2`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_code3`                AS `planc_code3`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_code4`                AS `planc_code4`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_code5`                AS `planc_code5`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_code6`                AS `planc_code6`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_code7`                AS `planc_code7`,
       `cesdb_aroriginal`.`lpin_plancuentas`.`planc_orden`                AS `planc_orden`,
       concat(`cesdb_aroriginal`.`lpin_plancuentas`.`planc_codigoc`, '.') AS `planc_codigocp`
from `cesdb_aroriginal`.`lpin_plancuentas`;

