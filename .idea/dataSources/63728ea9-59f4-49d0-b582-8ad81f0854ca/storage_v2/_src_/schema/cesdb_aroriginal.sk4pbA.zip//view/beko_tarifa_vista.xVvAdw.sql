create definer = root@localhost view beko_tarifa_vista as
select `cesdb_aroriginal`.`beko_tarifa`.`tari_codigo` AS `hill_taricodigo`,
       `cesdb_aroriginal`.`beko_tarifa`.`impu_codigo` AS `hill_impucodigo`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_nombre` AS `tari_nombre`
from `cesdb_aroriginal`.`beko_tarifa`;

