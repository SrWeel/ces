create definer = root@localhost view beko_detalles_compra as
select concat(`cesdb_aroriginal`.`lpin_productocompra`.`prcomp_id`, 'det')          AS `data`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_codigoatc`       AS `docdet_codprincipal`,
       ''                                                                           AS `docdet_codaux`,
       `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_nombrecomercial` AS `docdet_descripcion`,
       `cesdb_aroriginal`.`lpin_productocompra`.`prcomp_cantidad`                   AS `docdet_cantidad`,
       `cesdb_aroriginal`.`lpin_productocompra`.`prcomp_preciounitario`             AS `docdet_preciou`,
       `cesdb_aroriginal`.`lpin_productocompra`.`prcomp_descuentodolar`             AS `docdet_descuento`,
       `cesdb_aroriginal`.`lpin_productocompra`.`prcomp_subtotal`                   AS `docdet_total`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_valor`                                AS `docdet_valorimpuesto`,
       `cesdb_aroriginal`.`lpin_productocompra`.`prcomp_impucodigo`                 AS `impu_codigo`,
       `cesdb_aroriginal`.`lpin_productocompra`.`prcomp_taricodigo`                 AS `tari_codigo`,
       `cesdb_aroriginal`.`lpin_productocompra`.`compra_enlace`                     AS `compra_enlace`,
       'producto'                                                                   AS `tipo`
from ((`cesdb_aroriginal`.`lpin_productocompra` left join `cesdb_aroriginal`.`beko_tarifa`
       on (`cesdb_aroriginal`.`lpin_productocompra`.`prcomp_taricodigo` =
           `cesdb_aroriginal`.`beko_tarifa`.`tari_codigo`)) left join `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`
      on (`cesdb_aroriginal`.`lpin_productocompra`.`cuadrobm_id` =
          `cesdb_aroriginal`.`dns_cuadrobasicomedicamentos`.`cuadrobm_id`))
union
select concat(`cesdb_aroriginal`.`lpin_cuentacompra`.`cuecomp_id`, 'cue') AS `data`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`planc_codigoc`             AS `docdet_codprincipal`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`planc_codigoc`             AS `docdet_codaux`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`cuecomp_descripext`        AS `docdet_descripcion`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`cuecomp_cantidad`          AS `docdet_cantidad`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`cuecomp_preciounitario`    AS `docdet_preciou`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`cuecomp_descuentodolar`    AS `docdet_descuento`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`cuecomp_subtotal`          AS `docdet_total`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_valor`                      AS `docdet_valorimpuesto`,
       `cesdb_aroriginal`.`beko_tarifa`.`impu_codigo`                     AS `impu_codigo`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_codigo`                     AS `tari_codigo`,
       `cesdb_aroriginal`.`lpin_cuentacompra`.`compra_enlace`             AS `compra_enlace`,
       'cuenta'                                                           AS `tipo`
from ((`cesdb_aroriginal`.`lpin_cuentacompra` left join `cesdb_aroriginal`.`beko_tarifa`
       on (`cesdb_aroriginal`.`lpin_cuentacompra`.`taric_id` =
           `cesdb_aroriginal`.`beko_tarifa`.`tari_id`)) left join `cesdb_aroriginal`.`lpin_plancuentas`
      on (`cesdb_aroriginal`.`lpin_cuentacompra`.`planc_codigoc` =
          `cesdb_aroriginal`.`lpin_plancuentas`.`planc_codigoc`))
union
select concat(`cesdb_aroriginal`.`dns_activosfijos`.`acfi_id`, 'cue') AS `data`,
       `cesdb_aroriginal`.`dns_activosfijos`.`acfi_codigo`            AS `docdet_codprincipal`,
       ''                                                             AS `docdet_codaux`,
       `cesdb_aroriginal`.`dns_activosfijos`.`acfi_nombre`            AS `docdet_descripcion`,
       '1'                                                            AS `docdet_cantidad`,
       `cesdb_aroriginal`.`dns_activosfijos`.`acfi_valorcompra`       AS `docdet_preciou`,
       '0'                                                            AS `docdet_descuento`,
       `cesdb_aroriginal`.`dns_activosfijos`.`acfi_subtotal`          AS `docdet_total`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_valor`                  AS `docdet_valorimpuesto`,
       `cesdb_aroriginal`.`beko_tarifa`.`impu_codigo`                 AS `impu_codigo`,
       `cesdb_aroriginal`.`beko_tarifa`.`tari_codigo`                 AS `tari_codigo`,
       `cesdb_aroriginal`.`dns_activosfijos`.`compra_enlace`          AS `compra_enlace`,
       'activof'                                                      AS `tipo`
from (`cesdb_aroriginal`.`dns_activosfijos` left join `cesdb_aroriginal`.`beko_tarifa`
      on (`cesdb_aroriginal`.`dns_activosfijos`.`tarif_id` = `cesdb_aroriginal`.`beko_tarifa`.`tari_id`));

