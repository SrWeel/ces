create definer = root@localhost view app_cliente_vista as
select `cesdb_aroriginal`.`app_cliente`.`clie_id`              AS `clie_id`,
       `cesdb_aroriginal`.`app_cliente`.`clie_rucci`           AS `clie_rucci`,
       `cesdb_aroriginal`.`app_cliente`.`clie_nombre`          AS `clie_nombre`,
       `cesdb_aroriginal`.`app_cliente`.`clie_apellido`        AS `clie_apellido`,
       `cesdb_aroriginal`.`app_cliente`.`clie_genero`          AS `clie_genero`,
       `cesdb_aroriginal`.`app_cliente`.`clie_fechanacimiento` AS `clie_fechanacimiento`,
       `cesdb_aroriginal`.`app_cliente`.`clie_email`           AS `clie_email`,
       `cesdb_aroriginal`.`app_cliente`.`clie_telefono`        AS `clie_telefono`,
       `cesdb_aroriginal`.`app_cliente`.`clie_registro`        AS `clie_registro`,
       `cesdb_aroriginal`.`app_cliente`.`clie_registrado`      AS `clie_registrado`
from `cesdb_aroriginal`.`app_cliente`;

