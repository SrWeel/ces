create definer = root@localhost view efacsistema_genestablecimiento_nc as
select `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`estab_id`       AS `estabnc_id`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`emp_id`         AS `emp_id`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`estab_codigo`   AS `estabnc_codigo`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`estab_estado`   AS `estabnc_estado`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`centro_id`      AS `centro_id`,
       `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`tipocmp_codigo` AS `tipocmp_codigo`
from `cesdb_aroriginal`.`efacsistema_genestablecimiento`
where `cesdb_aroriginal`.`efacsistema_genestablecimiento`.`tipocmp_codigo` = '04';

