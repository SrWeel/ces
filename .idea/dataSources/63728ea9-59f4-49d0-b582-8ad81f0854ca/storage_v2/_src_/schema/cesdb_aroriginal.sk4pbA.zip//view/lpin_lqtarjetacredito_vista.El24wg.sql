create definer = `remote-user`@`192.168.100.10` view lpin_lqtarjetacredito_vista as
select `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`ldtc_id`                        AS `ldtc_id`,
       `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_fechaemision`             AS `tpliq_fechaemision`,
       `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_id`                       AS `tpliq_id`,
       `cesdb_arcombos`.`app_tipodocliq`.`tpliq_nombre`                            AS `tpliq_nombre`,
       `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`proveelq_id`                    AS `proveelq_id`,
       `cesdb_aroriginal`.`app_proveedor`.`provee_nombre`                          AS `provee_nombre`,
       `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_cuentabanco`              AS `tpliq_cuentabanco`,
       `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_ndocumento`               AS `tpliq_ndocumento`,
       round((select sum(`cesdb_aroriginal`.`lpin_lqtransacciones`.`lqtran_apagar`) AS `total`
              from `cesdb_aroriginal`.`lpin_lqtransacciones`
              where `cesdb_aroriginal`.`lpin_lqtransacciones`.`tpliq_enlace` =
                    `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_enlace`), 2) AS `valor`,
       round((select sum(`cesdb_aroriginal`.`tarjeta_retencion_detalle`.`compretdet_valorretenido`) AS `retencion`
              from `cesdb_aroriginal`.`tarjeta_retencion_detalle`
              where `cesdb_aroriginal`.`tarjeta_retencion_detalle`.`tpliq_enlace` =
                    `cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_enlace`), 2) AS `retencion`
from ((`cesdb_aroriginal`.`lpin_lqtarjetacredito` left join `cesdb_arcombos`.`app_tipodocliq`
       on (`cesdb_aroriginal`.`lpin_lqtarjetacredito`.`tpliq_id` =
           `cesdb_arcombos`.`app_tipodocliq`.`tpliq_id`)) left join `cesdb_aroriginal`.`app_proveedor`
      on (`cesdb_aroriginal`.`lpin_lqtarjetacredito`.`proveelq_id` = `cesdb_aroriginal`.`app_proveedor`.`provee_id`));

