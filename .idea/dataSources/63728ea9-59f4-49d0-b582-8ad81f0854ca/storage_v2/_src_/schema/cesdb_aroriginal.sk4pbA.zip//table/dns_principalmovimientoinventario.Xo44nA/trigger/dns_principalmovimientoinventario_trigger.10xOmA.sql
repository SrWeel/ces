create definer = root@localhost trigger dns_principalmovimientoinventario_TRIGGER
    after insert
    on dns_principalmovimientoinventario
    for each row
BEGIN

DECLARE totalactual double;

DECLARE ingresoegreso double;

DECLARE multiplicado double; 

DECLARE saldo double;

DECLARE movimiento int;

DECLARE periodac int;





select tipom_valor into ingresoegreso from dns_tipomovimiento where tipom_id=NEW.tipom_id;



select perio_anio into periodac from dns_periodobodega where perio_activo=1;



select moviin_id into movimiento from dns_principalstockactual where moviin_id=NEW.moviin_id;

IF movimiento IS NULL THEN



insert into dns_principalstockactual (centro_id,cuadrobm_id,unid_id,moviin_cantidadunidadconsumo,uniddesg_id,moviin_id,stock_cantidad,stock_fechaureg,stock_signo,stock_periodo) VALUES (NEW.centro_id,NEW.cuadrobm_id,NEW.unid_id,NEW.moviin_cantidadunidadconsumo,NEW.uniddesg_id,NEW.moviin_id,NEW.moviin_totalenunidadconsumo,now(),ingresoegreso,periodac);



END IF;

END;

