create definer = `remote-user`@`192.168.100.10` view beko_documentocabecera_vista as
select `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`                                            AS `doccab_id`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_ndocumento`                                    AS `doccab_ndocumento`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_rucci_cliente`                                 AS `doccab_rucci_cliente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_nombrerazon_cliente`                           AS `doccab_nombrerazon_cliente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_apellidorazon_cliente`                         AS `doccab_apellidorazon_cliente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_fechaemision_cliente`                          AS `doccab_fechaemision_cliente`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_estadosri`                                     AS `doccab_estadosri`,
       if(`cesdb_aroriginal`.`beko_documentocabecera`.`doccab_anulado` = 1, 'ANULADO',
          '')                                                                                             AS `doccab_anulado`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_motivoanulado`                                 AS `doccab_motivoanulado`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_total`                                         AS `doccab_total`,
       date_format(`cesdb_aroriginal`.`beko_documentocabecera`.`doccab_fechaemision_cliente`,
                   '%Y-%m-%d')                                                                            AS `fecha_dia`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`emp_id`                                               AS `emp_id`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`usua_id`                                              AS `usua_id`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`centro_id`                                            AS `centro_id`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`tippo_id`                                             AS `tippo_id`,
       round(if((select sum(`cesdb_aroriginal`.`ventas_retencion_detalle`.`compretdet_valorretenido`) AS `totalret`
                 from `cesdb_aroriginal`.`ventas_retencion_detalle`
                 where `cesdb_aroriginal`.`ventas_retencion_detalle`.`compra_enlace` =
                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`) is null, 0,
                (select sum(`cesdb_aroriginal`.`ventas_retencion_detalle`.`compretdet_valorretenido`) AS `totalret`
                 from `cesdb_aroriginal`.`ventas_retencion_detalle`
                 where `cesdb_aroriginal`.`ventas_retencion_detalle`.`compra_enlace` =
                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`)),
             2)                                                                                           AS `retencion`,
       round(if(`cesdb_aroriginal`.`beko_documentocabecera`.`doccab_subtotaliva` +
                `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_subtotalsiniva` is null, 0,
                `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_subtotaliva` +
                `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_subtotalsiniva`), 2)                  AS `subtotal`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_iva`                                           AS `doccab_iva`,
       if(`cesdb_aroriginal`.`beko_documentocabecera`.`doccab_anulado` = '1', 0, if(
               `cesdb_aroriginal`.`beko_documentocabecera`.`tipocmp_codigo` = '04' and
               `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_ndocuafecta` <> '', '0', round(
                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_total` - round(if(
                                                                                                  (select sum(`cesdb_aroriginal`.`ventas_retencion_detalle`.`compretdet_valorretenido`) AS `totalret`
                                                                                                   from `cesdb_aroriginal`.`ventas_retencion_detalle`
                                                                                                   where
                                                                                                       `cesdb_aroriginal`.`ventas_retencion_detalle`.`compra_enlace` =
                                                                                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`) is null,
                                                                                                  0,
                                                                                                  (select sum(`cesdb_aroriginal`.`ventas_retencion_detalle`.`compretdet_valorretenido`) AS `totalret`
                                                                                                   from `cesdb_aroriginal`.`ventas_retencion_detalle`
                                                                                                   where
                                                                                                       `cesdb_aroriginal`.`ventas_retencion_detalle`.`compra_enlace` =
                                                                                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`)),
                                                                                          2) -
                       round(if((select sum(`nc`.`doccab_total`) AS `total`
                                 from `cesdb_aroriginal`.`beko_documentocabecera` `nc`
                                 where `nc`.`tipocmp_codigo` = '04'
                                   and `nc`.`doccab_anulado` = 0
                                   and `nc`.`doccab_ndocuafecta` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_ndocumento`) is null, 0,
                                (select sum(`nc`.`doccab_total`) AS `total`
                                 from `cesdb_aroriginal`.`beko_documentocabecera` `nc`
                                 where `nc`.`tipocmp_codigo` = '04'
                                   and `nc`.`doccab_anulado` = 0
                                   and `nc`.`doccab_ndocuafecta` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_ndocumento`)), 2) -
                       round(if((select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                                 from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                       on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                           `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                                 where `cesdb_aroriginal`.`lpin_cobropagodetalle`.`doccabcp_id` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`
                                   and `cesdb_aroriginal`.`lpin_cobropago`.`ttra_id` = 1) is null, 0,
                                (select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                                 from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                       on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                           `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                                 where `cesdb_aroriginal`.`lpin_cobropagodetalle`.`doccabcp_id` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`
                                   and `cesdb_aroriginal`.`lpin_cobropago`.`ttra_id` = 1)), 2) +
                       round(if((select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                                 from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                       on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                           `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                                 where `cesdb_aroriginal`.`lpin_cobropagodetalle`.`doccabcp_id` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`
                                   and `cesdb_aroriginal`.`lpin_cobropago`.`ttra_id` = 2) is null, 0,
                                (select sum(`cesdb_aroriginal`.`lpin_cobropagodetalle`.`crpadet_valorapagar`) AS `total`
                                 from (`cesdb_aroriginal`.`lpin_cobropago` join `cesdb_aroriginal`.`lpin_cobropagodetalle`
                                       on (`cesdb_aroriginal`.`lpin_cobropago`.`crb_enlace` =
                                           `cesdb_aroriginal`.`lpin_cobropagodetalle`.`crb_enlace`))
                                 where `cesdb_aroriginal`.`lpin_cobropagodetalle`.`doccabcp_id` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`
                                   and `cesdb_aroriginal`.`lpin_cobropago`.`ttra_id` = 2)), 2) - if(round(
                                                                                                            (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                                                                                             from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                                                                                                   on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                       `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                                                                                             where
                                                                                                                 `cesdb_arextension`.`lpin_crucedetalle`.`crudet_documentoventa` =
                                                                                                                 `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`),
                                                                                                            2) is null,
                                                                                                    0, round(
                                                                                                            (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                                                                                             from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                                                                                                   on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                       `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                                                                                             where
                                                                                                                 `cesdb_arextension`.`lpin_crucedetalle`.`crudet_documentoventa` =
                                                                                                                 `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`),
                                                                                                            2)) - if(
                               round(
                                       (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                        from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                              on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                  `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                        where `cesdb_aroriginal`.`lpin_crucedocumentos`.`doccabcr_id` =
                                              `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`), 2) is null, 0,
                               round(
                                       (select sum(`cesdb_arextension`.`lpin_crucedetalle`.`crudet_valorpago`) AS `documentoval`
                                        from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucedetalle`
                                              on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                  `cesdb_arextension`.`lpin_crucedetalle`.`crudoc_enlace`))
                                        where `cesdb_aroriginal`.`lpin_crucedocumentos`.`doccabcr_id` =
                                              `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`), 2)) -
                       if(round((select sum(`cesdb_arextension`.`lpin_crucecuentas`.`crucue_valorpago`) AS `anticipo`
                                 from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucecuentas`
                                       on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                           `cesdb_arextension`.`lpin_crucecuentas`.`crudoc_enlace`))
                                 where `cesdb_aroriginal`.`lpin_crucedocumentos`.`doccabcr_id` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`), 2) is null, 0,
                          round((select sum(`cesdb_arextension`.`lpin_crucecuentas`.`crucue_valorpago`) AS `anticipo`
                                 from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_crucecuentas`
                                       on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                           `cesdb_arextension`.`lpin_crucecuentas`.`crudoc_enlace`))
                                 where `cesdb_aroriginal`.`lpin_crucedocumentos`.`doccabcr_id` =
                                       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`), 2)) -
                       round(ifnull((select sum(`cesdb_aroriginal`.`lpin_pagosfacturas`.`pgofac_valor`)
                                     from `cesdb_aroriginal`.`lpin_pagosfacturas`
                                     where `cesdb_aroriginal`.`lpin_pagosfacturas`.`doccab_id` =
                                           `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`), 0), 2) - if(round(
                                                                                                                         (select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `documentoval`
                                                                                                                          from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                                                                                                                                on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                                    `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                                                                                                                          where
                                                                                                                              `cesdb_aroriginal`.`lpin_crucedocumentos`.`doccabcr_id` =
                                                                                                                              `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`),
                                                                                                                         2) is null,
                                                                                                                 0,
                                                                                                                 round(
                                                                                                                         (select sum(`cesdb_arextension`.`lpin_cruceanticipos`.`cruant_valorpago`) AS `documentoval`
                                                                                                                          from (`cesdb_aroriginal`.`lpin_crucedocumentos` join `cesdb_arextension`.`lpin_cruceanticipos`
                                                                                                                                on (`cesdb_aroriginal`.`lpin_crucedocumentos`.`crudoc_enlace` =
                                                                                                                                    `cesdb_arextension`.`lpin_cruceanticipos`.`crudoc_enlace`))
                                                                                                                          where
                                                                                                                              `cesdb_aroriginal`.`lpin_crucedocumentos`.`doccabcr_id` =
                                                                                                                              `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_id`),
                                                                                                                         2)),
                       2)))                                                                               AS `saldo`,
       `cesdb_arcombos`.`beko_tipocomprobante`.`tipocmp_nombre`                                           AS `tipocmp_nombre`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_pgacont`                                       AS `doccab_pgacont`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`tipocmp_codigo`                                       AS `tipocmp_codigo`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`proveeve_id`                                          AS `proveevebu_id`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_retfechaemision`                               AS `doccab_retfechaemision`,
       `cesdb_aroriginal`.`beko_documentocabecera`.`doccab_adicional`                                     AS `doccab_adicional`
from (`cesdb_aroriginal`.`beko_documentocabecera` join `cesdb_arcombos`.`beko_tipocomprobante`
      on (`cesdb_aroriginal`.`beko_documentocabecera`.`tipocmp_codigo` =
          `cesdb_arcombos`.`beko_tipocomprobante`.`tipocmp_codigo`));

