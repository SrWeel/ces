create definer = root@localhost view dns_newlaboratorio_vista as
select `cesdb_aroriginal`.`dns_newlaboratorio`.`lab_id`                                                              AS `lab_id`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`lab_idexterno`                                                       AS `lab_idexterno`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`lab_tablaexterno`                                                    AS `lab_tablaexterno`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`centro_id`                                                           AS `centro_id`,
       `cesdb_aroriginal`.`dns_centrosalud`.`centro_nombre`                                                          AS `centro_nombre`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`prio_id`                                                             AS `prio_id`,
       `cesdb_aroriginal`.`dns_prioridad`.`prio_nombre`                                                              AS `prioridad`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`clie_id`                                                             AS `clie_id`,
       (select `cesdb_aroriginal`.`dns_diagnosticolaboratorio`.`diagn_descripcion`
        from `cesdb_aroriginal`.`dns_diagnosticolaboratorio`
        where `cesdb_aroriginal`.`dns_diagnosticolaboratorio`.`lab_enlace` =
              `cesdb_aroriginal`.`dns_newlaboratorio`.`lab_enlace`
        order by `cesdb_aroriginal`.`dns_diagnosticolaboratorio`.`diagn_id` desc
        limit 1)                                                                                                     AS `diagnostico`,
       `cesdb_aroriginal`.`dns_serviciolab`.`serlab_nombre`                                                          AS `servicio`,
       concat(`cesdb_aroriginal`.`app_cliente`.`clie_nombre`, ' ',
              `cesdb_aroriginal`.`app_cliente`.`clie_apellido`)                                                      AS `paciente`,
       `cesdb_aroriginal`.`app_cliente`.`clie_rucci`                                                                 AS `lab_hc`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`lab_fecharegistro`                                                   AS `lab_fecharegistro`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`usua_id`                                                             AS `usua_id`,
       concat(`cesdb_aroriginal`.`app_usuario`.`usua_nombre`, ' ',
              `cesdb_aroriginal`.`app_usuario`.`usua_apellido`)                                                      AS `profesional`,
       `cesdb_aroriginal`.`dns_newlaboratorio`.`atenc_id`                                                            AS `atenc_id`
from ((((((`cesdb_aroriginal`.`dns_newlaboratorio` join `cesdb_aroriginal`.`app_cliente`
           on (`cesdb_aroriginal`.`dns_newlaboratorio`.`clie_id` =
               `cesdb_aroriginal`.`app_cliente`.`clie_id`)) join `cesdb_aroriginal`.`dns_centrosalud`
          on (`cesdb_aroriginal`.`dns_newlaboratorio`.`centro_id` =
              `cesdb_aroriginal`.`dns_centrosalud`.`centro_id`)) join `cesdb_aroriginal`.`app_usuario`
         on (`cesdb_aroriginal`.`dns_newlaboratorio`.`usua_id` =
             `cesdb_aroriginal`.`app_usuario`.`usua_id`)) join `cesdb_aroriginal`.`dns_prioridad`
        on (`cesdb_aroriginal`.`dns_newlaboratorio`.`prio_id` =
            `cesdb_aroriginal`.`dns_prioridad`.`prio_id`)) left join `cesdb_aroriginal`.`dns_atencion`
       on (`cesdb_aroriginal`.`dns_newlaboratorio`.`atenc_id` =
           `cesdb_aroriginal`.`dns_atencion`.`atenc_id`)) left join `cesdb_aroriginal`.`dns_serviciolab`
      on (`cesdb_aroriginal`.`dns_newlaboratorio`.`serlab_id` = `cesdb_aroriginal`.`dns_serviciolab`.`serlab_id`));

